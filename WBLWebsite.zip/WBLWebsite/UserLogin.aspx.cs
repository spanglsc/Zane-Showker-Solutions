﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Net.Mail;

namespace WBLWebsite
{
    public partial class UserLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void UserLoginControls_Authenticate(object sender, AuthenticateEventArgs e)
        {
            if (Membership.ValidateUser(UserLoginControls.UserName, UserLoginControls.Password) == true)
            {
                e.Authenticated = true;
                string[] role = Roles.GetRolesForUser(UserLoginControls.UserName);
                if (role[0] != "Administrator" && e.Authenticated == true)
                {
                    FormsAuthentication.RedirectFromLoginPage(UserLoginControls.UserName, true);
                }
                else
                {
                    Server.Transfer("/Login.aspx",true);
                }
            }
        }
        protected void ForgotPassword(object sender, EventArgs e)
        {
            MembershipUser User = Membership.GetUser(UserLoginControls.UserName);
            string password = User.GetPassword();
            MailAddress email = new MailAddress("fordepj@dukes.jmu.edu");
            EmailPassword("fordepj@dukes.jmu.edu", password);
        }
        private void EmailPassword(string email, string password)
        {
            string smtpAddress = "smtp.mail.yahoo.com";
            int portNumber = 587;
            bool enableSSL = true;
            try
            {
                MailMessage Message = new MailMessage("WBLtest@yahoo.com", email);
                Message.Subject = "Your Password";
                Message.Body = "Your password is: " + Server.HtmlEncode(password);

                SmtpClient SmtpMail = new SmtpClient(smtpAddress,portNumber);
                SmtpMail.Credentials = new NetworkCredential("WBLtest@yahoo.com", "passwordtest");
                SmtpMail.EnableSsl = enableSSL;
                SmtpMail.Send(Message);
            }
            catch(Exception a)
            {
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WBLWebsite.Instructors
{
    public partial class MyClasses : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {

            }
            MembershipUser u = Membership.GetUser();
            string email = u.UserName;

        }
        public void dataBind()
        {

            GridViewRow row = table.SelectedRow;

            String Selected = row.Cells[1].Text;
            int ClassID = Convert.ToInt32(Selected);

            string strConnString = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(strConnString))
            {
                using (SqlCommand cmd1 = new SqlCommand())
                {
                    cmd1.CommandText = "select FileID, Title, ContentType from ClassFiles where ContentType = 'video/mp4' AND ClassID = '" + ClassID + "'";
                    cmd1.Connection = con;
                    con.Open();
                    DataList1.DataSource = cmd1.ExecuteReader();
                    DataList1.DataBind();
                    con.Close();
                }
                using (SqlCommand cmd2 = new SqlCommand())
                {
                    cmd2.CommandText = "select FileID, Title, ContentType from ClassFiles where ContentType = 'audio/mp3' AND ClassID = '" + ClassID + "'";
                    cmd2.Connection = con;
                    con.Open();
                    GridView1.DataSource = cmd2.ExecuteReader();
                    GridView1.DataBind();
                    con.Close();
                }
                using (SqlCommand cmd3 = new SqlCommand())
                {
                    cmd3.CommandText = "select FileID, Title, ContentType from ClassFiles where ContentType = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' OR ContentType = 'application/vnd.ms-powerpoint' OR ContentType = 'application/vnd.openxmlformats-officedocument.presentationml.presentation' OR ContentType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' OR ContentType = 'application/pdf' OR ContentType = 'image/jpeg' OR ContentType = 'image/png' AND ClassID = '" + ClassID + "'";
                    cmd3.Connection = con;
                    con.Open();
                    GridView2.DataSource = cmd3.ExecuteReader();
                    GridView2.DataBind();
                    con.Close();
                }
            }

        }
        protected void displayClasses()
        {
            MembershipUser u = Membership.GetUser();
            string email = u.UserName;
            database.SelectCommand = "SELECT * FROM [Class] Where Email = '" + email + "' ORDER BY [ClassID]";
        }
        protected void btnUpload_Click(object sender, EventArgs e)
        {
            if (FileUpload1.HasFile)
            {
                String a = Path.GetFileName(FileUpload1.PostedFile.FileName);
                String f = Path.GetExtension(a);
                f = f.ToLower();

                string[] acceptedFileTypes = new string[9];
                acceptedFileTypes[0] = ".pdf";
                acceptedFileTypes[1] = ".docx";
                acceptedFileTypes[2] = ".jpg";
                acceptedFileTypes[3] = ".png";
                acceptedFileTypes[4] = ".mp3";
                acceptedFileTypes[5] = ".mp4";
                acceptedFileTypes[6] = ".ppt";
                acceptedFileTypes[7] = ".pptx";
                acceptedFileTypes[8] = ".xlsx";
                for (int i = 0; i <= 8; i++)
                {
                    if (f == acceptedFileTypes[i])
                    {
                        int fileSize = FileUpload1.PostedFile.ContentLength;
                        if (fileSize < 1000000000)
                        {
                            string filename = Path.GetFileName(FileUpload1.PostedFile.FileName);
                            string contentType = FileUpload1.PostedFile.ContentType;
                            using (Stream fs = FileUpload1.PostedFile.InputStream)
                            {
                                using (BinaryReader br = new BinaryReader(fs))
                                {
                                    byte[] bytes = br.ReadBytes((Int32)fs.Length);
                                    string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;


                                    GridViewRow row = table.SelectedRow;

                                    String Selected = row.Cells[1].Text;
                                    int intSelectedClass = Convert.ToInt32(Selected);

                                    using (SqlConnection con = new SqlConnection(constr))
                                    {
                                        string query = "insert into ClassFiles(FileID, Title, ClassID, Datas, ContentType) values (11, @Title, @ClassID, @Data, @ContentType)";
                                        using (SqlCommand cmd = new SqlCommand(query))
                                        {
                                            cmd.Connection = con;
                                            cmd.Parameters.AddWithValue("@Title", filename);
                                            cmd.Parameters.AddWithValue("@ClassID", intSelectedClass);
                                            cmd.Parameters.AddWithValue("@Data", bytes);
                                            cmd.Parameters.AddWithValue("@ContentType", contentType);
                                            con.Open();
                                            cmd.ExecuteNonQuery();
                                            con.Close();
                                        }
                                    }
                                }
                            }

                            Response.Redirect(Request.Url.AbsoluteUri);

                            using (BinaryReader br = new BinaryReader(FileUpload1.PostedFile.InputStream))
                            {

                                GridViewRow row = table.SelectedRow;

                                String Selected = row.Cells[1].Text;
                                int intSelectedClass = Convert.ToInt32(Selected);

                                byte[] bytes = br.ReadBytes((int)FileUpload1.PostedFile.InputStream.Length);
                                string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
                                SqlConnection sc = new SqlConnection(constr);
                                sc.Open();
                                System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand();
                                command.Connection = sc;
                                using (SqlConnection con = new SqlConnection(constr))
                                {
                                    using (SqlCommand cmd = new SqlCommand())
                                    {
                                        if (f == ".mp4")
                                        {
                                            cmd.CommandText = "insert into ClassFiles(FileID, Title, ClassID, Datas, ContentType) values (3, @Title, @ClassID, @Data, @ContentType)";

                                            cmd.Parameters.AddWithValue("@Title", Path.GetFileName(FileUpload1.PostedFile.FileName));
                                            cmd.Parameters.AddWithValue("@ClassID", intSelectedClass);
                                            cmd.Parameters.AddWithValue("@Data", bytes);
                                            cmd.Parameters.AddWithValue("@ContentType", "video/mp4");
                                            cmd.Connection = con;
                                            con.Open();
                                            cmd.ExecuteNonQuery();
                                            con.Close();
                                        }
                                        if (f == ".mp3")
                                        {
                                            cmd.CommandText = "insert into ClassFiles(FileID, Title, ClassID, Datas, ContentType) values (3, @Title, @ClassID, @Data, @ContentType)";
                                            cmd.Parameters.AddWithValue("@Title", Path.GetFileName(FileUpload1.PostedFile.FileName));
                                            cmd.Parameters.AddWithValue("@ClassID", intSelectedClass);
                                            cmd.Parameters.AddWithValue("@Data", bytes);
                                            cmd.Parameters.AddWithValue("@ContentType", "audio/mpeg3");
                                            cmd.Connection = con;
                                            con.Open();
                                            cmd.ExecuteNonQuery();
                                            con.Close();
                                        }
                                    }
                                }
                            }
                            Response.Redirect(Request.Url.AbsoluteUri);
                        }
                        else
                        {
                            UploadStatus.Text = "You cannot upload files larger than 1GB";
                        }
                    }
                    else
                    {
                        UploadStatus.Text = "You can only upload .docx, .pdf, .jpg, .png, .mp3, or .mp4 file types";
                    }
                }
            }
            else
            {
                UploadStatus.Text = "You did not specify a file to upload";
            }
        }
        protected void DownloadFile(object sender, EventArgs e)
        {
            int id = int.Parse((sender as LinkButton).CommandArgument);
            byte[] bytes;
            string fileName, contentType;
            string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = "select Title, Datas, ContentType from ClassFiles where FileID = @Id";
                    cmd.Parameters.AddWithValue("@Id", id);
                    cmd.Connection = con;
                    con.Open();
                    using (SqlDataReader sdr = cmd.ExecuteReader())
                    {
                        sdr.Read();
                        bytes = (byte[])sdr["Datas"];
                        contentType = sdr["ContentType"].ToString();
                        fileName = sdr["Title"].ToString();
                    }

                    con.Close();
                }
            }

            Response.Clear();
            Response.Buffer = true;
            Response.Charset = "";
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.ContentType = contentType;
            Response.AppendHeader("Content-Disposition", "attachment; filename=" + fileName);
            Response.BinaryWrite(bytes);
            Response.Flush();
            Response.End();
        }
        protected void DeleteFile(object sender, EventArgs e)
        {

            int id = int.Parse((sender as LinkButton).CommandArgument);
            string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = "delete from ClassFiles where FileID = @Id";
                    cmd.Parameters.AddWithValue("@Id", id);
                    cmd.Connection = con;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                }
            }
        }
        public void ViewClassInstructor(object sender, EventArgs e)
        {
            table.Visible = false;
            dataBind();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WBLWebsite.Instructors
{
    public partial class Attendance : System.Web.UI.Page
    {
        private string data;
        private int classNumber;

        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                validationMessage.Visible = false;
            }
            lblDate.Text = DateTime.Today.ToShortDateString();
        }


        protected void Button1_Click(object sender, EventArgs e)
        {
            int id;
            string firstName;
            string lastName;

            foreach (GridViewRow row in gvRoster.Rows)
            {
                if (row.RowType == DataControlRowType.DataRow)
                {
                    CheckBox chkRow = (row.Cells[0].FindControl("chkSelect") as CheckBox);
                    if (chkRow.Checked)
                    {
                        id = Int32.Parse(row.Cells[1].Text);
                        firstName = row.Cells[2].Text;
                        lastName = row.Cells[3].Text;
                        data = data + id + " ,  " + firstName + " , " + lastName + "<br>";

                        classNumber = Int32.Parse(ddlClass.SelectedItem.Value);
                        String date = Convert.ToDateTime(DateTime.Today).ToString("dd/MM/yyyy");

                        string validateSubmission = WBLWebsite.Attendance.takeAttendance(classNumber, id, date);
                        if(validateSubmission != "Success!")
                        {
                            validationMessage.Text = validateSubmission;
                            validationMessage.CssClass = "col-lg-6 alert-danger";
                            validationMessage.Visible = true;
                        }
                        else
                        {
                            validationMessage.Text = validateSubmission;
                            validationMessage.CssClass = "col-lg-6 alert-success";
                            validationMessage.Visible = true;
                        }
                        System.Data.SqlClient.SqlConnection sc = new System.Data.SqlClient.SqlConnection();
                        sc.ConnectionString = @"Server =LOCALHOST; Database = WBL;Trusted_Connection=Yes;";
                        sc.Open();

                        SqlCommand insert = new SqlCommand();
                        insert.CommandType = System.Data.CommandType.Text;
                        insert.Connection = sc;

                        insert.CommandText = "SELECT duration FROM Class WHERE ClassID =" + ddlClass.SelectedValue;
                        int duration = 0;
                        try
                        {
                            duration = ((int)insert.ExecuteScalar());
                        }
                        catch(Exception a)
                        {

                        }

                        SqlCommand inserts = new SqlCommand();
                        inserts.CommandType = System.Data.CommandType.Text;
                        inserts.Connection = sc;

                        inserts.CommandText = "UPDATE SysUser SET BucksBalance = BucksBalance + " + duration + " WHERE UserID =" + id;
                        inserts.ExecuteNonQuery();

                        sc.Close();
                    }
                }
            }
            ddlSearchDate.DataBind();
        }

        protected void btnRoster_Click(object sender, EventArgs e)
        {
            classNumber = Int32.Parse(ddlClass.SelectedItem.Value);

            gvRoster.Visible = true;
            SqlDataSource1.SelectCommand = "select s.userID, s.firstName, s.lastName from StudentClass c, SysUser s where  s.UserID = c.UserID and c.classID = " + classNumber;
            gvRoster.DataBind();
            lblSelectStudents.Visible = true;

        }
        protected void btnSearchAttendance_Click(object sender, EventArgs e)
        {

            DateTime date = DateTime.Parse(ddlSearchDate.SelectedItem.Value);
            int tempNum = Int32.Parse(ddlSeachClassName.SelectedItem.Value);

            gvAttendance.Visible = true;

            SqlDataSource4.SelectCommand = "select s.FirstName, s.LastName from  Attendance a, SysUser s, StudentClass cr  where (a.UserID = s.UserID) and (cr.UserID = a.UserID) and (a.ClassID = '" + tempNum + "') and (a.CurrentDate = '" + date + "')";
            gvAttendance.DataBind();
        }
    }
}
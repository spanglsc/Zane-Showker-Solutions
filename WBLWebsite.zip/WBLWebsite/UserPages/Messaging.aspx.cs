﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Web.Security;

namespace WBLWebsite.UserPages
{
    public partial class Messaging : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                populateUser();
            }
        }

        public void populateUser()
        {
            MembershipUser u = Membership.GetUser();
            string User = u.UserName;
            SqlCommand cmd = new SqlCommand("select UserID, firstname +' ' + lastname as fullname from SysUser where email != '" + User + "'");
            System.Data.SqlClient.SqlConnection sc = new System.Data.SqlClient.SqlConnection();
            string conn = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            sc.ConnectionString = conn;
            cmd.CommandType = CommandType.Text;
            cmd.Connection = sc;
            sc.Open();
            userList.DataSource = cmd.ExecuteReader();
            userList.DataValueField = "UserID";
            userList.DataTextField = "fullname";
            userList.DataBind();
            sc.Close();
            userList.Items.Insert(0, new ListItem("Select User", ""));
        }

        protected void Send_Click(object sender, EventArgs e)
        {
           try
            {
                System.Data.SqlClient.SqlConnection sc = new System.Data.SqlClient.SqlConnection();
                string conn = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
                sc.ConnectionString = conn;
                SqlCommand cmd = new SqlCommand("insert into Message([MessageTitle],[MessageContent],[SenderUserID],[ReceiverUserID]) values (@MessageTitle, @MessageContent, @SenderUserID, @ReceiverUserID)");
                cmd.CommandType = CommandType.Text;
                cmd.Connection = sc;
                cmd.Parameters.AddWithValue("@MessageTitle", txtSubject.Text);
                cmd.Parameters.AddWithValue("@MessageContent", txtMessage.Text);
                cmd.Parameters.AddWithValue("@SenderUserID", SysUser.getUserByID());
                cmd.Parameters.AddWithValue("@ReceiverUserID", userList.SelectedValue);
                sc.Open();
                cmd.ExecuteNonQuery();
                sc.Close();
                MessageStatus.Text = "Message successfully sent.";
                txtSubject.Text = "";
                txtMessage.Text = "";
                userList.SelectedIndex = 0;
            }
            catch (Exception a)
            {
                MessageStatus.Text = "You have not filled out enough information to send.";
            }
        }
        private void LoadList()
        {
            List<string> titleList = new List<string>();
            string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;

            using (SqlConnection connection = new SqlConnection(constr))
            {
                string query = "select MessageTitle from dbo.Message where ReceiverUserID = 31"; // change 31 to user id of current user
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            titleList.Add(reader.GetString(0));
                        }
                    }
                    titles.DataSource = titleList;
                    titles.DataBind();
                    connection.Close();
                }
            }
        }

        protected void showmessage_Click(object sender, EventArgs e)
        {
            try
            {
                string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;

                using (SqlConnection connection = new SqlConnection(constr))
                {

                    string query = "select SysUser.FirstName + ' ' + SysUser.LastName as Name, Message.MessageTitle, Message.MessageContent from SysUser join Message on SysUser.UserID = Message.SenderUserID where message.messagetitle = '" + Convert.ToString(titles.SelectedItem.Value) + "'";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        connection.Open();
                        SqlDataReader reader = command.ExecuteReader();
                        while (reader.Read())
                        {
                            From.Text = "<b>From: </b>" + reader[0] as string;
                            subject.Text = "<b>Subject:</b> " + reader[1] as string;
                            content.Text = "<b>Message: </b><br />" + reader[2] as string;
                            //break for single row or you can continue if you have multiple rows...
                            break;
                        }
                    }
                    connection.Close();
                }
            }
            catch
            {
                DeleteStatus.Text = "You have not selected a message to show.";
            }
        }

        protected void deletemessage_Click(object sender, EventArgs e)
        {
            try
            {
                string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;

                using (SqlConnection connection = new SqlConnection(constr))
                {

                    string query = "delete from message where messagetitle = '" + Convert.ToString(titles.SelectedItem.Value) + "'";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        connection.Open();
                        command.ExecuteReader();
                    }
                    connection.Close();
                    LoadList();
                    From.Text = "";
                    subject.Text = "";
                    content.Text = "";
                    DeleteStatus.Text = "Message successfully deleted.";
                }
            }
            catch
            {
                DeleteStatus.Text = "You have not selected a message to delete.";
            }
        }
    }
}

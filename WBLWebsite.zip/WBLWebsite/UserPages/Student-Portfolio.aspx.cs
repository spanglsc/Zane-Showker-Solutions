﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Data.SqlClient;
using System.Configuration;

namespace WBLWebsite.UserPages
{
    public partial class Student_Portfolio : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                string email = (string)(Session["Email"]);
                if (email != null)
                {
                    NamePortfolio.Text = SysUser.getUserByName(email);
                    BindGrid();
                }
                else
                {
                    Server.Transfer("Default.aspx");
                }
            }
        }
        private void BindGrid()
        {
            string email = (string)(Session["Email"]);
            string strConnString = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(strConnString))
            {
                using (SqlCommand cmd1 = new SqlCommand())
                {
                    cmd1.CommandText = "select PortfolioID, Name, ContentType from Portfolio where ContentType = 'video/mp4' AND UserID in (select UserID from SysUser where email = '" + email + "')";
                    cmd1.Connection = con;
                    con.Open();
                    DataList1.DataSource = cmd1.ExecuteReader();
                    DataList1.DataBind();
                    con.Close();
                }
                using (SqlCommand cmd2 = new SqlCommand())
                {
                    cmd2.CommandText = "select PortfolioID, Name, ContentType from Portfolio where ContentType = 'audio/mp3' AND UserID in (select UserID from SysUser where email = '" + email + "')";
                    cmd2.Connection = con;
                    con.Open();
                    GridView1.DataSource = cmd2.ExecuteReader();
                    GridView1.DataBind();
                    con.Close();
                }
                using (SqlCommand cmd3 = new SqlCommand())
                {
                    cmd3.CommandText = "select PortfolioID, Name, ContentType from Portfolio where ContentType = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' OR ContentType = 'application/pdf' OR ContentType = 'image/jpeg' OR ContentType = 'image/png' AND UserID in (select UserID from SysUser where email = '" + email + "')";
                    cmd3.Connection = con;
                    con.Open();
                    GridView2.DataSource = cmd3.ExecuteReader();
                    GridView2.DataBind();
                    con.Close();
                }
            }
        }
        protected void DownloadFile(object sender, EventArgs e)
        {
            int id = int.Parse((sender as LinkButton).CommandArgument);
            byte[] bytes;
            string fileName, contentType;
            string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = "select Name, Data, ContentType from Portfolio where PortfolioID =@Id";
                    cmd.Parameters.AddWithValue("@Id", id);
                    cmd.Connection = con;
                    con.Open();
                    using (SqlDataReader sdr = cmd.ExecuteReader())
                    {
                        sdr.Read();
                        bytes = (byte[])sdr["Data"];
                        contentType = sdr["ContentType"].ToString();
                        fileName = sdr["Name"].ToString();
                    }
                    con.Close();
                }
            }
            Response.Clear();
            Response.Buffer = true;
            Response.Charset = "";
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.ContentType = contentType;
            Response.AppendHeader("Content-Disposition", "attachment; filename=" + fileName);
            Response.BinaryWrite(bytes);
            Response.Flush();
            Response.End();
        }
    }
}
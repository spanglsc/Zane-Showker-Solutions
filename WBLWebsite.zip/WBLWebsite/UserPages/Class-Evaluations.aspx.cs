﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WBLWebsite.UserPages
{
    public partial class Class_Evaluations : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        public void insertEval(int UserID, String HearAbout, String Saf, String NeedsChange, String Skills, String NewThings, String Learn, String Mediums,
            String Friends, String Motivated, String FeelHappy, String FeelPositive, String WorkYoung, String Stress, String Respect,
            String ResistNeg, String FeelComf, String Careers, String CareerGoals, String Community, String Cont, String FinishSchool, String FindJob, String TeacherName,
            String TeacherShows, String TeacherTime, String TeacherEnvi, String TeacherOrg, String TeacherFeed, String TeacherSafe, String TeacherLearn,
            String TeacherPlan, String TeacherJobWell, String TeacherSupport, String TeacherStr, String TeacherImprove, String TeacherComm,
            String Describe, String FinishFinal, String Recognition, String Technology, String Mixing, String Scratching, String Professional, String Presentation)
        {
            try
            {
                System.Data.SqlClient.SqlConnection sc = new System.Data.SqlClient.SqlConnection();
                sc.ConnectionString = @"Server=LOCALHOST;Database=WBL;Trusted_Connection=Yes;";
                sc.Open();
                System.Data.SqlClient.SqlCommand insert = new System.Data.SqlClient.SqlCommand();
                insert.Connection = sc;
                insert.CommandText = "INSERT into [dbo].[InstructorEvaluation] values (@UserID, @HearAbout, @Saf, @NeedsChange, @Skills, @NewThings, @Learn, @Mediums, @Friends, @Motivated, @FeelHappy, @FeelPositive, @WorkYoung, @Stress, @Respect, @ResistNeg, @FeelComf, @Careers, @CareerGoals, @Community, @Cont, @FinishSchool, @FindJob, @TeacherName, @TeacherShows, @TeacherTime, @TeacherEnvi, @TeacherOrg, @TeacherFeed, @TeacherSafe, @TeacherLearn, @TeacherPlan, @TeacherJobWell, @TeacherSupport, @TeacherStr, @TeacherImprove, @TeacherComm, @Additional, @Describe, @FinishFinal, @Recognition, @Technology, @Mixing, @Scratching, @Professional, @Presentation)";
                insert.Parameters.AddWithValue("@UserID", UserID);
                insert.Parameters.AddWithValue("@HearAbout", HearAbout);
                insert.Parameters.AddWithValue("@Saf", Saf);
                insert.Parameters.AddWithValue("@NeedsChange", NeedsChange);
                insert.Parameters.AddWithValue("@Skils", Skills);
                insert.Parameters.AddWithValue("@NewThings", NewThings);
                insert.Parameters.AddWithValue("@Mediums", Mediums);
                insert.Parameters.AddWithValue("@Friends", Friends);
                insert.Parameters.AddWithValue("@Motivated", Motivated);
                insert.Parameters.AddWithValue("@FeelHappy", FeelHappy);
                insert.Parameters.AddWithValue("@FeelPositive", FeelPositive);
                insert.Parameters.AddWithValue("@WorkYoung", WorkYoung);
                insert.Parameters.AddWithValue("@Stress", Stress);
                insert.Parameters.AddWithValue("@Respect", Respect);
                insert.Parameters.AddWithValue("@ResistNeg", ResistNeg);
                insert.Parameters.AddWithValue("@FeelComf", FeelComf);
                insert.Parameters.AddWithValue("@Careers", Careers);
                insert.Parameters.AddWithValue("@CareerGoals", CareerGoals);
                insert.Parameters.AddWithValue("@Community", Community);
                insert.Parameters.AddWithValue("@Cont", Cont);
                insert.Parameters.AddWithValue("@FinishSchool", FinishSchool);
                insert.Parameters.AddWithValue("@FindJob", FindJob);
                insert.Parameters.AddWithValue("@TeacherName", TeacherName);
                insert.Parameters.AddWithValue("@TeacherShows", TeacherShows);
                insert.Parameters.AddWithValue("@TeacherTime", TeacherTime);
                insert.Parameters.AddWithValue("@TeacherEnvi", TeacherEnvi);
                insert.Parameters.AddWithValue("@TeacherOrg", TeacherOrg);
                insert.Parameters.AddWithValue("@TeacherFeed", TeacherFeed);
                insert.Parameters.AddWithValue("@TeacherSafe", TeacherSafe);
                insert.Parameters.AddWithValue("@TeacherLearn", TeacherLearn);
                insert.Parameters.AddWithValue("@TeacherPlan", TeacherPlan);
                insert.Parameters.AddWithValue("@TeacherSupport", TeacherSupport);
                insert.Parameters.AddWithValue("@TeacherStr", TeacherStr);
                insert.Parameters.AddWithValue("@TeacherImprove", TeacherImprove);
                insert.Parameters.AddWithValue("@TeacherComm", TeacherComm);
                insert.Parameters.AddWithValue("@Describe", Describe);
                insert.Parameters.AddWithValue("@FinishFinal", FinishFinal);
                insert.Parameters.AddWithValue("@Recognition", Recognition);
                insert.Parameters.AddWithValue("@Technology", Technology);
                insert.Parameters.AddWithValue("@Mixing", Mixing);
                insert.Parameters.AddWithValue("@Scratching", Scratching);
                insert.Parameters.AddWithValue("@Professional", Professional);
                insert.Parameters.AddWithValue("@Presentation", Presentation);
                insert.ExecuteNonQuery();
                sc.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public IEnumerable<Control> GetAll(Control control, Type type)
        {
            var controls = control.Controls.Cast<Control>();
            return controls.SelectMany(ctrls => GetAll(ctrls, type)).Concat(controls).Where(c => c.GetType() == type);
        }

        protected void btnSubmitEval_Click(Object sender, EventArgs e)
        {
            String NewThings;
            if (rbNewThings1.Checked)
                NewThings = "Completely Disagree";
            if (rbNewThings2.Checked)
                NewThings = "Disagree";
            if (rbNewThings3.Checked)
                NewThings = "Neither Agree nor Disagree";
            if (rbNewThings4.Checked)
                NewThings = "Agree";
            else
                NewThings = "Completely Agree";

            String Learn;
            if (rbLearn1.Checked)
                Learn = "Completely Disagree";
            if (rbLearn2.Checked)
                Learn = "Disagree";
            if (rbLearn3.Checked)
                Learn = "Neither Agree nor Disagree";
            if (rbLearn4.Checked)
                Learn = "Agree";
            else
                Learn = "Completely Agree";

            String Mediums;
            if (rbMediums1.Checked)
                Mediums = "Completely Disagree";
            if (rbMediums2.Checked)
                Mediums = "Disagree";
            if (rbMediums3.Checked)
                Mediums = "Neither Agree nor Disagree";
            if (rbMediums4.Checked)
                Mediums = "Agree";
            else
                Mediums = "Completely Agree";

            String Friends;
            if (rbFriends1.Checked)
                Friends = "Completely Disagree";
            if (rbFriends2.Checked)
                Friends = "Disagree";
            if (rbFriends3.Checked)
                Friends = "Neither Agree nor Disagree";
            if (rbFriends4.Checked)
                Friends = "Agree";
            else
                Friends = "Completely Agree";

            String Motivated;
            if (rbMotivated1.Checked)
                Motivated = "Completely Disagree";
            if (rbMotivated2.Checked)
                Motivated = "Disagree";
            if (rbMotivated3.Checked)
                Motivated = "Neither Agree nor Disagree";
            if (rbMotivated4.Checked)
                Motivated = "Agree";
            else
                Motivated = "Completely Agree";

            String FeelHappy;
            if (rbFeelHappy1.Checked)
                FeelHappy = "Completely Disagree";
            if (rbFeelHappy2.Checked)
                FeelHappy = "Disagree";
            if (rbFeelHappy3.Checked)
                FeelHappy = "Neither Agree nor Disagree";
            if (rbFeelHappy4.Checked)
                FeelHappy = "Agree";
            else
                FeelHappy = "Completely Agree";

            String FeelPositive;
            if (rbFeelPositive1.Checked)
                FeelPositive = "Completely Disagree";
            if (rbFeelPositive2.Checked)
                FeelPositive = "Disagree";
            if (rbFeelPositive3.Checked)
                FeelPositive = "Neither Agree nor Disagree";
            if (rbFeelPositive4.Checked)
                FeelPositive = "Agree";
            else
                FeelPositive = "Completely Agree";

            String WorkYoung;
            if (rbWorkYoung1.Checked)
                WorkYoung = "Completely Disagree";
            if (rbWorkYoung2.Checked)
                WorkYoung = "Disagree";
            if (rbWorkYoung3.Checked)
                WorkYoung = "Neither Agree nor Disagree";
            if (rbWorkYoung4.Checked)
                WorkYoung = "Agree";
            else
                WorkYoung = "Completely Agree";

            String Stress;
            if (rbStress1.Checked)
                Stress = "Completely Disagree";
            if (rbStress2.Checked)
                Stress = "Disagree";
            if (rbStress3.Checked)
                Stress = "Neither Agree nor Disagree";
            if (rbStress4.Checked)
                Stress = "Agree";
            else
                Stress = "Completely Agree";

            String Respect;
            if (rbRespect1.Checked)
                Respect = "Completely Disagree";
            if (rbRespect2.Checked)
                Respect = "Disagree";
            if (rbRespect3.Checked)
                Respect = "Neither Agree nor Disagree";
            if (rbRespect4.Checked)
                Respect = "Agree";
            else
                Respect = "Completely Agree";

            String ResistNeg;
            if (rbResistNeg1.Checked)
                ResistNeg = "Completely Disagree";
            if (rbResistNeg2.Checked)
                ResistNeg = "Disagree";
            if (rbResistNeg3.Checked)
                ResistNeg = "Neither Agree nor Disagree";
            if (rbResistNeg4.Checked)
                ResistNeg = "Agree";
            else
                ResistNeg = "Completely Agree";

            String FeelComf;
            if (rbFeelComf1.Checked)
                FeelComf = "Completely Disagree";
            if (rbFeelComf2.Checked)
                FeelComf = "Disagree";
            if (rbFeelComf3.Checked)
                FeelComf = "Neither Agree nor Disagree";
            if (rbFeelComf4.Checked)
                FeelComf = "Agree";
            else
                FeelComf = "Completely Agree";

            String Careers;
            if (rbCareers1.Checked)
                Careers = "Completely Disagree";
            if (rbCareers2.Checked)
                Careers = "Disagree";
            if (rbCareers3.Checked)
                Careers = "Neither Agree nor Disagree";
            if (rbCareers4.Checked)
                Careers = "Agree";
            else
                Careers = "Completely Agree";

            String CareerGoals;
            if (rbCareerGoals1.Checked)
                CareerGoals = "Completely Disagree";
            if (rbCareerGoals2.Checked)
                CareerGoals = "Disagree";
            if (rbCareerGoals3.Checked)
                CareerGoals = "Neither Agree nor Disagree";
            if (rbCareerGoals4.Checked)
                CareerGoals = "Agree";
            else
                CareerGoals = "Completely Agree";

            String Community;
            if (rbCommunity1.Checked)
                Community = "Completely Disagree";
            if (rbCommunity2.Checked)
                Community = "Disagree";
            if (rbCommunity3.Checked)
                Community = "Neither Agree nor Disagree";
            if (rbCommunity4.Checked)
                Community = "Agree";
            else
                Community = "Completely Agree";

            String Cont;
            if (rbCont1.Checked)
                Cont = "Completely Disagree";
            if (rbCont2.Checked)
                Cont = "Disagree";
            if (rbCont3.Checked)
                Cont = "Neither Agree nor Disagree";
            if (rbCont4.Checked)
                Cont = "Agree";
            else
                Cont = "Completely Agree";

            String FinishSchool;
            if (rbFinishSchool1.Checked)
                FinishSchool = "Completely Disagree";
            if (rbFinishSchool2.Checked)
                FinishSchool = "Disagree";
            if (rbFinishSchool3.Checked)
                FinishSchool = "Neither Agree nor Disagree";
            if (rbFinishSchool4.Checked)
                FinishSchool = "Agree";
            else
                FinishSchool = "Completely Agree";

            String FindJob;
            if (rbFindJob1.Checked)
                FindJob = "Completely Disagree";
            if (rbFindJob2.Checked)
                FindJob = "Disagree";
            if (rbFindJob3.Checked)
                FindJob = "Neither Agree nor Disagree";
            if (rbFindJob4.Checked)
                FindJob = "Agree";
            else
                FindJob = "Completely Agree";

            String TeacherShows;
            if (rbTeacherShows1.Checked)
                TeacherShows = "Unsatisfactory";
            if (rbTeacherShows2.Checked)
                TeacherShows = "Needs Improvement";
            if (rbTeacherShows3.Checked)
                TeacherShows = "Meets Expectations";
            if (rbTeacherShows4.Checked)
                TeacherShows = "Consistently Exceeds Expectations";
            else
                TeacherShows = "Exceptional";

            String TeacherTime;
            if (rbTeacherTime1.Checked)
                TeacherTime = "Unsatisfactory";
            if (rbTeacherTime2.Checked)
                TeacherTime = "Needs Improvement";
            if (rbTeacherTime3.Checked)
                TeacherTime = "Meets Expectations";
            if (rbTeacherTime4.Checked)
                TeacherTime = "Consistently Exceeds Expectations";
            else
                TeacherTime = "Exceptional";

            String TeacherEnvi;
            if (rbTeacherEnvi1.Checked)
                TeacherEnvi = "Unsatisfactory";
            if (rbTeacherEnvi2.Checked)
                TeacherEnvi = "Needs Improvement";
            if (rbTeacherEnvi3.Checked)
                TeacherEnvi = "Meets Expectations";
            if (rbTeacherEnvi4.Checked)
                TeacherEnvi = "Consistently Exceeds Expectations";
            else
                TeacherEnvi = "Exceptional";

            String TeacherOrg;
            if (rbTeacherOrg1.Checked)
                TeacherOrg = "Unsatisfactory";
            if (rbTeacherOrg2.Checked)
                TeacherOrg = "Needs Improvement";
            if (rbTeacherOrg3.Checked)
                TeacherOrg = "Meets Expectations";
            if (rbTeacherOrg4.Checked)
                TeacherOrg = "Consistently Exceeds Expectations";
            else
                TeacherOrg = "Exceptional";

            String TeacherFeed;
            if (rbTeacherFeed1.Checked)
                TeacherFeed = "Unsatisfactory";
            if (rbTeacherFeed2.Checked)
                TeacherFeed = "Needs Improvement";
            if (rbTeacherFeed3.Checked)
                TeacherFeed = "Meets Expectations";
            if (rbTeacherFeed4.Checked)
                TeacherFeed = "Consistently Exceeds Expectations";
            else
                TeacherFeed = "Exceptional";

            String TeacherSafe;
            if (rbTeacherSafe1.Checked)
                TeacherSafe = "Unsatisfactory";
            if (rbTeacherSafe2.Checked)
                TeacherSafe = "Needs Improvement";
            if (rbTeacherSafe3.Checked)
                TeacherSafe = "Meets Expectations";
            if (rbTeacherSafe4.Checked)
                TeacherSafe = "Consistently Exceeds Expectations";
            else
                TeacherSafe = "Exceptional";

            String TeacherLearn;
            if (rbTeacherLearn1.Checked)
                TeacherLearn = "Unsatisfactory";
            if (rbTeacherLearn2.Checked)
                TeacherLearn = "Needs Improvement";
            if (rbTeacherLearn3.Checked)
                TeacherLearn = "Meets Expectations";
            if (rbTeacherLearn4.Checked)
                TeacherLearn = "Consistently Exceeds Expectations";
            else
                TeacherLearn = "Exceptional";

            String TeacherPlan;
            if (rbTeacherPlan1.Checked)
                TeacherPlan = "Unsatisfactory";
            if (rbTeacherPlan2.Checked)
                TeacherPlan = "Needs Improvement";
            if (rbTeacherPlan3.Checked)
                TeacherPlan = "Meets Expectations";
            if (rbTeacherPlan4.Checked)
                TeacherPlan = "Consistently Exceeds Expectations";
            else
                TeacherPlan = "Exceptional";

            String TeacherJobWell;
            if (rbTeacherJobWell1.Checked)
                TeacherJobWell = "Unsatisfactory";
            if (rbTeacherJobWell2.Checked)
                TeacherJobWell = "Needs Improvement";
            if (rbTeacherJobWell3.Checked)
                TeacherJobWell = "Meets Expectations";
            if (rbTeacherJobWell4.Checked)
                TeacherJobWell = "Consistently Exceeds Expectations";
            else
                TeacherJobWell = "Exceptional";

            String TeacherSupport;
            if (rbTeacherSupport1.Checked)
                TeacherSupport = "Unsatisfactory";
            if (rbTeacherSupport2.Checked)
                TeacherSupport = "Needs Improvement";
            if (rbTeacherSupport3.Checked)
                TeacherSupport = "Meets Expectations";
            if (rbTeacherSupport4.Checked)
                TeacherSupport = "Consistently Exceeds Expectations";
            else
                TeacherSupport = "Exceptional";

            insertEval(SysUser.userSearch(txtFName.Text, txtLName.Text), rblHearAbout.SelectedValue, rblSaf.SelectedValue, txtNeedsChange.Text, txtSkills.Text,
                NewThings, Learn, Mediums, Friends, Motivated, FeelHappy, FeelPositive, WorkYoung, Stress, Respect, ResistNeg, FeelComf, Careers,
                CareerGoals, Community, Cont, FinishSchool, FindJob, txtInstructorName.Text, TeacherShows, TeacherTime, TeacherEnvi, TeacherOrg, TeacherFeed, TeacherSafe, TeacherLearn,
                TeacherPlan, TeacherJobWell, TeacherSupport, txtStrengths.Text, txtImprovement.Text, txtComments.Text,
                rblDescribe.SelectedValue, rblFinishFinal.SelectedValue, txtRecognition.Text, txtTechnology.Text, txtMixing.Text, txtScratching.Text, txtProfessional.Text, txtPresentation.Text);

            //clearing text boxes 
            txtNeedsChange.Text = "";
            txtSkills.Text = "";
            txtInstructorName.Text = "";
            txtStrengths.Text = "";
            txtImprovement.Text = "";
            txtComments.Text = "";
            txtRecognition.Text = "";
            txtTechnology.Text = "";
            txtMixing.Text = "";
            txtScratching.Text = "";
            txtProfessional.Text = "";
            txtPresentation.Text = "";

            //un-checking all radiobuttons
            var cntls = GetAll(this, typeof(RadioButton));
            foreach (Control cntrl in cntls)
            {
                RadioButton _rb = (RadioButton)cntrl;
                if (_rb.Checked)
                {
                    _rb.Checked = false;
                }
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WBLWebsite.UserPages
{
    public partial class Student_Evaluations : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        public void insertEval(int UserID, String ShowUp, String OnTime, String Contribute, String Criticism, String Attitude, String Motivated,
            String FinProject, String Engaged, String Strengths, String Growth, String Other, String Recognition, String Technology, String Mixing,
            String Scratching, String Professional, String Presentation)
        {
            try
            {
                System.Data.SqlClient.SqlConnection sc = new System.Data.SqlClient.SqlConnection();
                sc.ConnectionString = @"Server=LOCALHOST;Database=WBL;Trusted_Connection=Yes;";
                sc.Open();
                System.Data.SqlClient.SqlCommand insert = new System.Data.SqlClient.SqlCommand();
                insert.Connection = sc;
                insert.CommandText = "INSERT into [dbo].[InstructorEvaluation] values (@UserID, @ShowUp, @OnTime, @Contribute, @Criticism, @Attitude, @Motivated, @FinProject, @Engaged, @Strengths, @Growth, @Other, @Recognition, @Technology, @Mixing, @Scratching, @Professional, @Presentation)";
                insert.Parameters.AddWithValue("@UserID", UserID);
                insert.Parameters.AddWithValue("@ShowUp", ShowUp);
                insert.Parameters.AddWithValue("@OnTime", OnTime);
                insert.Parameters.AddWithValue("@Contribute", Contribute);
                insert.Parameters.AddWithValue("@Criticism", Criticism);
                insert.Parameters.AddWithValue("@Attitude", Attitude);
                insert.Parameters.AddWithValue("@Motivated", Motivated);
                insert.Parameters.AddWithValue("@FinProject", FinProject);
                insert.Parameters.AddWithValue("@Engaged", Engaged);
                insert.Parameters.AddWithValue("@Strengths", Strengths);
                insert.Parameters.AddWithValue("@Growth", Growth);
                insert.Parameters.AddWithValue("@Other", Other);
                insert.Parameters.AddWithValue("@Recognition", Recognition);
                insert.Parameters.AddWithValue("@Technology", Technology);
                insert.Parameters.AddWithValue("@Mixing", Mixing);
                insert.Parameters.AddWithValue("@Scratching", Scratching);
                insert.Parameters.AddWithValue("@Professional", Professional);
                insert.Parameters.AddWithValue("@Presentation", Presentation);
                insert.ExecuteNonQuery();
                sc.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public IEnumerable<Control> GetAll(Control control, Type type)
        {
            var controls = control.Controls.Cast<Control>();
            return controls.SelectMany(ctrls => GetAll(ctrls, type)).Concat(controls).Where(c => c.GetType() == type);
        }

        protected void btnSubmitEval_Click(Object sender, EventArgs e)
        {
            String ShowUp;
            if (rbShowUp1.Checked)
                ShowUp = "Unsatisfactory";
            if (rbShowUp2.Checked)
                ShowUp = "Needs Improvement";
            if (rbShowUp3.Checked)
                ShowUp = "Meets Expectations";
            if (rbShowUp4.Checked)
                ShowUp = "Consistently Exceeds Expectations";
            else
                ShowUp = "Exceptional";

            String OnTime;
            if (rbOnTime1.Checked)
                OnTime = "Unsatisfactory";
            if (rbOnTime2.Checked)
                OnTime = "Needs Improvement";
            if (rbOnTime3.Checked)
                OnTime = "Meets Expectations";
            if (rbOnTime4.Checked)
                OnTime = "Consistently Exceeds Expectations";
            else
                OnTime = "Exceptional";

            String Contribute;
            if (rbContribute1.Checked)
                Contribute = "Unsatisfactory";
            if (rbContribute2.Checked)
                Contribute = "Needs Improvement";
            if (rbContribute3.Checked)
                Contribute = "Meets Expectations";
            if (rbContribute4.Checked)
                Contribute = "Consistently Exceeds Expectations";
            else
                Contribute = "Exceptional";

            String Criticism;
            if (rbCriticism1.Checked)
                Criticism = "Unsatisfactory";
            if (rbCriticism2.Checked)
                Criticism = "Needs Improvement";
            if (rbCriticism3.Checked)
                Criticism = "Meets Expectations";
            if (rbCriticism4.Checked)
                Criticism = "Consistently Exceeds Expectations";
            else
                Criticism = "Exceptional";

            String Attitude;
            if (rbAttitude1.Checked)
                Attitude = "Unsatisfactory";
            if (rbAttitude2.Checked)
                Attitude = "Needs Improvement";
            if (rbAttitude3.Checked)
                Attitude = "Meets Expectations";
            if (rbAttitude4.Checked)
                Attitude = "Consistently Exceeds Expectations";
            else
                Attitude = "Exceptional";

            String Motivated;
            if (rbMotivated1.Checked)
                Motivated = "Unsatisfactory";
            if (rbMotivated2.Checked)
                Motivated = "Needs Improvement";
            if (rbMotivated3.Checked)
                Motivated = "Meets Expectations";
            if (rbMotivated4.Checked)
                Motivated = "Consistently Exceeds Expectations";
            else
                Motivated = "Exceptional";

            String FinProject;
            if (rbFinProject1.Checked)
                FinProject = "Unsatisfactory";
            if (rbFinProject2.Checked)
                FinProject = "Needs Improvement";
            if (rbFinProject3.Checked)
                FinProject = "Meets Expectations";
            if (rbFinProject4.Checked)
                FinProject = "Consistently Exceeds Expectations";
            else
                FinProject = "Exceptional";

            String Engaged;
            if (rbEngaged1.Checked)
                Engaged = "Unsatisfactory";
            if (rbEngaged2.Checked)
                Engaged = "Needs Improvement";
            if (rbEngaged3.Checked)
                Engaged = "Meets Expectations";
            if (rbEngaged4.Checked)
                Engaged = "Consistently Exceeds Expectations";
            else
                Engaged = "Exceptional";

            insertEval(SysUser.userSearch(txtFName.Text, txtLName.Text), ShowUp, OnTime, Contribute, Criticism, Attitude, Motivated, FinProject, Engaged,
                txtStrengths.Text, txtImprovement.Text, txtComments.Text, txtRecognition.Text, txtTechnology.Text, txtMixing.Text, txtScratching.Text, txtProfessional.Text, txtPresentation.Text);

            txtStrengths.Text = "";
            txtImprovement.Text = "";
            txtComments.Text = "";
            txtRecognition.Text = "";
            txtTechnology.Text = "";
            txtMixing.Text = "";
            txtScratching.Text = "";
            txtProfessional.Text = "";
            txtPresentation.Text = "";

            var cntls = GetAll(this, typeof(RadioButton));
            foreach (Control cntrl in cntls)
            {
                RadioButton _rb = (RadioButton)cntrl;
                if (_rb.Checked)
                {
                    _rb.Checked = false;
                }
            }
        }
    }
}
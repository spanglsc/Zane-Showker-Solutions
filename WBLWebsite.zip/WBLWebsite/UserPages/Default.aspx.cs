﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Data;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;

namespace WBLWebsite.UserPages
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                MembershipUser User = Membership.GetUser();
                string UserEmail = User.UserName;
                string[] role = Roles.GetRolesForUser(UserEmail);
                if (role[0] != "Student")
                {
                    DisplayBucks.Visible = false;
                }
                else
                {
                    string Bucks = SysUser.getBucksBalance();
                    BucksBalance.Text = Bucks;
                    DisplayBucks.Visible = true;
                }
                string strConnString = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
                using (SqlConnection con = new SqlConnection(strConnString))
                {
                    using (SqlCommand cmd1 = new SqlCommand())
                    {
                        cmd1.CommandText = "select top 5 SysUser.FirstName, SysUser.LastName, Portfolio.PortfolioID, Portfolio.Name, Portfolio.ContentType from SysUser join Portfolio on SysUser.UserID = Portfolio.UserID where Portfolio.ContentType = 'audio/mp3' order by Portfolio.DateCreated desc";
                        cmd1.Connection = con;
                        con.Open();
                        Feed.DataSource = cmd1.ExecuteReader();
                        Feed.DataBind();
                        con.Close();
                    }
                }
            }
        }
        protected void Send_Click(object sender, EventArgs e)
        {
            try
            {
                System.Data.SqlClient.SqlConnection sc = new System.Data.SqlClient.SqlConnection();
                string conn = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
                sc.ConnectionString = conn;
                SqlCommand cmd = new SqlCommand("insert into Message([MessageTitle],[MessageContent],[SenderUserID],[ReceiverUserID]) values (@MessageTitle, @MessageContent, @SenderUserID, @ReceiverUserID)");
                cmd.CommandType = CommandType.Text;
                cmd.Connection = sc;
                cmd.Parameters.AddWithValue("@MessageTitle", txtSubject.Text);
                cmd.Parameters.AddWithValue("@MessageContent", txtMessage.Text);
                cmd.Parameters.AddWithValue("@SenderUserID", SysUser.getUserByID());
                cmd.Parameters.AddWithValue("@ReceiverUserID", userList.SelectedValue);
                sc.Open();
                cmd.ExecuteNonQuery();
                sc.Close();
                MessageStatus.Text = "Message successfully sent.";
                txtSubject.Text = "";
                txtMessage.Text = "";
                userList.SelectedIndex = 0;
            }
            catch (Exception a)
            {
                MessageStatus.Text = "You have not filled out enough information to send.";
            }
        }
    }
}
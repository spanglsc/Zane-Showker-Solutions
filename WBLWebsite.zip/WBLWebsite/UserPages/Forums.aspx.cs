﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Data.SqlClient;
using System.Configuration;

namespace WBLWebsite
{
    public partial class Forums : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                populateForums();
                
            }
        }
        public void populateForums()
        {
            string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            SqlConnection sc = new SqlConnection(constr);
            sc.Open();
            System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand();
            command.Connection = sc;
            MembershipUser User = Membership.GetUser();
            string UserEmail = User.UserName;
            command.CommandText = "select * from Forums order by ForumID";
            command.ExecuteNonQuery();
            SqlDataReader reader = command.ExecuteReader();
            int result = 0;
            int count = 0;
            string title = "";
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    count++;
                }
            }
            int i = 0;
            int[] forumArray = new int[count];
            reader.Close();
            SqlDataReader IDreader = command.ExecuteReader();
            if (IDreader.HasRows)
            {
                while (IDreader.Read())
                {
                    result = IDreader.GetInt32(0);
                    title = IDreader.GetString(1);
                    forumArray[i] = result;
                    i++;
                }
            }
            for (int j = 0; j < forumArray.Length; j++)
            {
                try
                {
                    Label newLabel = new Label();
                    newLabel.ID = "Discussion" + forumArray[j].ToString();
                    newLabel.Text = "Test";
                    discussionPlaceHolder.Controls.Add(newLabel);
                }
                catch(Exception a)
                {

                }       
            }
        }
    }
}
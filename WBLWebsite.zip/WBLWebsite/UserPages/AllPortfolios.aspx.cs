﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Security;

namespace WBLWebsite.UserPages
{
    public partial class AllPortfolios : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //getStudentPortfolios(); 
                GridViewPortfolio.DataBind();
            }
        }
        public static void getStudentPortfolios()
        {
            
        }
        protected void GridViewPortfolio_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow row = GridViewPortfolio.SelectedRow;
            String Selected = row.Cells[1].Text;

            int ID = Convert.ToInt32(Selected);
            string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            SqlConnection sc = new SqlConnection(constr);
            sc.Open();
            System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand();
            command.Connection = sc;
            command.CommandText = "select Email from sysuser where UserID = '" + ID + "'";
            command.ExecuteNonQuery();

            SqlDataReader reader = command.ExecuteReader();
            string result = "";
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    result = reader.GetString(0);
                }
            }
            string email = (result);
            Session.Add("Email", email);
            MembershipUser u = Membership.GetUser();
            string User = u.UserName;
            string[] role = Roles.GetRolesForUser(User);
            if (role[0] != "Administrator")
            {
                Server.Transfer("Student-Portfolio.aspx");
            }
            else
            {
                Server.Transfer("/AdminPages/Portfolio.aspx");
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Security;

namespace WBLWebsite.Students
{
    public partial class MyClasses : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            SqlConnection sc = new SqlConnection(constr);
            sc.Open();
            System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand();
            command.Connection = sc;
            MembershipUser User = Membership.GetUser();
            string UserEmail = User.UserName;
            command.CommandText = "select UserID from sysuser where email = '" + UserEmail + "'";
            command.ExecuteNonQuery();
            SqlDataReader reader = command.ExecuteReader();
            int result = 0;
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    result = reader.GetInt32(0);
                }
            }
            database.SelectCommand = "select * from class where classid in (select classid from studentclass where userID = '" + result + "')";
        }
    }
}
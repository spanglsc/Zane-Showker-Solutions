﻿function change(WhichLink) {
    var Link = document.getElementById(WhichLink);
    Link.style.background = '#A4A4A4';
    Link.style.fontcolor = '#23527c';
}
function changeBack(WhichLink) {
    var Link = document.getElementById(WhichLink);
    Link.style.background = '#B3B3B3';
    Link.style.fontcolor = '#fff';
}
function classHover(WhichLink) {
    var Link = document.getElementById(WhichLink);
    Link.style.boxShadow = '0 5px 8px 1px rgba(0,0,0,0.75)';
}
function classOut(WhichLink) {
    var Link = document.getElementById(WhichLink);
    Link.style.boxShadow = '0px 1px 4px 1px rgba(0,0,0,0.55)';
}
function showSubNav(WhichLink) {
    var Link = document.getElementById(WhichLink);
    Link.style.display = 'block';
}
function hideSubNav(WhichLink) {
    var Link = document.getElementById(WhichLink);
    Link.style.display = 'none';
}
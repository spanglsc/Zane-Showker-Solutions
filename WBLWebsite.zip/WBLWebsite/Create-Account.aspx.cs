﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace WBLWebsite
{
    public partial class Create_Account : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            TextBox[] controlsArray = { txtDOB, txtPhone, txtConf, txtPass, txtEmail, txtLName, txtFName };
            int count = 0;
            for (int i = 0; i < controlsArray.Length; i++)
            {
                if (controlsArray[i].Text == "")
                {
                    count++;
                    controlsArray[i].Attributes.Add("class", "form-control errorBox");
                    controlsArray[i].Focus();
                }
                else
                {
                    controlsArray[i].Attributes.Add("class", "form-control");
                }
            }
            if (count == 0)
            {
                int ID = Requested.checkRequestedID();
                Requested.createRequested(new Requested(ID, txtLName.Text, txtFName.Text, txtDOB.Text, selUserType.Value.ToString(), txtPhone.Text, txtEmail.Text));
                Membership.CreateUser(txtEmail.Text, txtPass.Text);
                Roles.AddUserToRole(txtEmail.Text, selUserType.Value.ToString());
                txtFName.Text = "";
                txtLName.Text = "";
                txtEmail.Text = "";
                txtPass.Text = "";
                txtConf.Text = "";
                txtPhone.Text = "";
                txtDOB.Text = "";
            }
        }
    }
}
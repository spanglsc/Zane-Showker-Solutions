﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Net;
using System.Net.Mail;
using System.Text.RegularExpressions;

namespace WBLWebsite
{
    public partial class Password_Recovery : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        bool IsValidEmail(string strIn)
        {
            // Return true if strIn is in valid e-mail format.
            return Regex.IsMatch(strIn, @"^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$");
        }
        protected void PasswordRecovery_VerifyingUser(object sender, LoginCancelEventArgs e)
        {
            if (!IsValidEmail(PasswordRecovery.UserName))
            {
                PasswordRecovery.UserNameInstructionText = "You must enter a valid e-mail address.";
                e.Cancel = true;
            }
            else
            {
                try
                {
                    MembershipUser User = Membership.GetUser(PasswordRecovery.UserName);
                    string password = User.GetPassword();
                    EmailPassword(User.ToString(), password);
                }
                catch (Exception a)
                {
                    PasswordRecovery.UserNameInstructionText = "There is no such address on record.";
                }
            }                
            
        }
        private void EmailPassword(string email, string password)
        {
            string smtpAddress = "smtp.mail.yahoo.com";
            int portNumber = 587;
            bool enableSSL = true;
            try
            {
                MailMessage Message = new MailMessage("WBLtest@yahoo.com", email);
                Message.Subject = "Your Password";
                Message.Body = "Your password is: " + Server.HtmlEncode(password);

                SmtpClient SmtpMail = new SmtpClient(smtpAddress, portNumber);
                SmtpMail.Credentials = new NetworkCredential("WBLtest@yahoo.com", "passwordtest");
                SmtpMail.EnableSsl = enableSSL;
                SmtpMail.Send(Message);
            }
            catch (Exception a)
            {
            }
        }
    }
}
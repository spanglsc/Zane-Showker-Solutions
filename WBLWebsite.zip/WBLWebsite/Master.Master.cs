﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WBLWebsite
{
    public partial class Master : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {           
            if (!IsPostBack)
            {
                MembershipUser u = Membership.GetUser();
                string User = u.UserName;
                string[] role = Roles.GetRolesForUser(User);
                Home.Visible = true;
                MyProfile.Visible = true;
                AllPortfolios.Visible = true;
                Forums.Visible = true;
                Events.Visible = true;
                AdminPortfolios.Visible = false;
                AdminForums.Visible = false;
                AdminAccounts.Visible = false;
                AdminPermissions.Visible = false;
                AdminClasses.Visible = false;
                AdminCalendar.Visible = false;
                Attendance.Visible = false;
                MyPortfolio.Visible = false;
                StudentClasses.Visible = false;
                ParentFeedback.Visible = false;
                StudentFeedback.Visible = false;
                Evaluations.Visible = false;
                InstructorClasses.Visible = false;
                switch (role[0])
                {
                    case "Administrator":
                        AdminPortfolios.Visible = true;
                        AdminForums.Visible = true;
                        AdminAccounts.Visible = true;
                        AdminPermissions.Visible = true;
                        AdminClasses.Visible = true;
                        AdminCalendar.Visible = true;
                        Attendance.Visible = false;
                        MyPortfolio.Visible = false;
                        StudentClasses.Visible = false;
                        ParentFeedback.Visible = false;
                        StudentFeedback.Visible = false;
                        Evaluations.Visible = true;
                        InstructorClasses.Visible = false;
                        MyProfile.Visible = false;
                        AllPortfolios.Visible = false;
                        Forums.Visible = false;
                        Events.Visible = false;
                        break;
                    case "Instructor":
                        Attendance.Visible = true;
                        InstructorClasses.Visible = true;
                        break;
                    case "Student":
                        StudentClasses.Visible = true;
                        StudentFeedback.Visible = true;
                        MyPortfolio.Visible = true;
                        ParentFeedback.Visible = false;
                        break;
                    case "Parent":
                        ParentFeedback.Visible = true;
                        break;
                    case "Cipher":
                        break;
                }
                string name = SysUser.getUserByName();
                Name.Text = name;
            }
        }
        protected void btnLogout_Click(Object sender, EventArgs e)
        {
            HttpContext.Current.Session.Clear();
            HttpContext.Current.Session.Abandon();
            HttpContext.Current.User = null;
            FormsAuthentication.SignOut();
            // clear authentication cookie
            HttpCookie cookie1 = new HttpCookie(FormsAuthentication.FormsCookieName, "");
            cookie1.Expires = DateTime.Now.AddYears(-1);
            Response.Cookies.Add(cookie1);
            FormsAuthentication.RedirectToLoginPage();
            Response.Redirect("/UserLogin.aspx");
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
namespace WBLWebsite
{
        public partial class Login : System.Web.UI.Page
        {
            protected void Page_Load(object sender, EventArgs e)
            {

            }
            protected void loginControls_Authenticate(object sender,AuthenticateEventArgs e)
            {
                if (Membership.ValidateUser(loginControls.UserName, loginControls.Password) == true)
                {
                    
                    e.Authenticated = true;
                    string[] role = Roles.GetRolesForUser(loginControls.UserName);
                    if (role[0] != "Administrator")
                    {
                        Server.Transfer("/UserLogin.aspx", true);
                    }
                    else
                    {
                        Session["user"] = User.Identity.Name;
                        FormsAuthentication.RedirectFromLoginPage(loginControls.UserName, true);
                    }
                }
                else
                {
                    Response.Write("<div class='errorMessage'><h4>Invalid Login</h4></div>");
                }
        }
    }
}

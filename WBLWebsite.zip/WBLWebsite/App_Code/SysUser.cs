﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Data;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;

namespace WBLWebsite
{
    public class SysUser
    {
        private int UserID;
        private string LName;
        private string FName;
        private string Address;
        private string City;
        private string State;
        private int Zip;
        private string PhoneNumber;
        private string EmailAddress;
        private string DOB;
        private string Bio;
        private string TypeID;
        private string picture;

        static DateTime toDateDOB;
        public SysUser()
        {

        }
        public SysUser(string LName, string FName, string DOB, string Address, string City, string State, int Zip, string PhoneNumber, string EmailAddress, string Bio, string TypeID, string picture)
        {
            setUserID(UserID);
            setLName(LName);
            setFName(FName);
            setDOB(DOB);
            setAddress(Address);
            setCity(City);
            setState(State);
            setZip(Zip);
            setPhoneNumber(PhoneNumber);
            setEmailAddress(EmailAddress);
            setTypeID(TypeID);
            setBio(Bio);
            setPicture(picture);
        }
        public SysUser(string LName, string FName, string DOB, string PhoneNumber, string EmailAddress, string TypeID)
        {
            setUserID(UserID);
            setLName(LName);
            setFName(FName);
            setDOB(DOB);
            setAddress(Address);
            setCity(City);
            setState(State);
            setZip(Zip);
            setPhoneNumber(PhoneNumber);
            setEmailAddress(EmailAddress);
            setTypeID(TypeID);
            setBio(Bio);
            setPicture(picture);
        }
        //accessors and mutators
        public int getUserID(int IDprefix)
        {
            int ID = 0;
            string strID = "";
            string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            SqlConnection sc = new SqlConnection(constr);
            sc.Open();
            SqlCommand command = new SqlCommand();
            command.Connection = sc;
            command.CommandText = "SELECT * FROM [dbo].[SysUser] where UserID Like '" + IDprefix + "%' Order By UserID";
            command.ExecuteNonQuery();

            SqlDataReader reader = command.ExecuteReader();

            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    ID = reader.GetInt32(0);
                }
                ID++;               
            }
            if (ID == 0)
            {
                strID = IDprefix + "0";
                ID = Convert.ToInt32(strID);
            }
            return ID;
        }
        public void setUserID(int newUserID)
        {
            this.UserID = newUserID;
        }
        public string getFName()
        {
            return FName;
        }
        public void setFName(string newFName)
        {
            this.FName = newFName;
        }
        public string getLName()
        {
            return LName;
        }
        public void setLName(string newLName)
        {
            this.LName = newLName;
        }
        public string getAddress()
        {
            return Address;
        }
        public void setAddress(string newAddress)
        {
            this.Address = newAddress;
        }
        public string getCity()
        {
            return City;
        }
        public void setCity(string newCity)
        {
            this.City = newCity;
        }
        public string getState()
        {
            return State;
        }
        public void setState(string newState)
        {
            this.State = newState;
        }
        public int getZip()
        {
            return Zip;
        }
        public void setZip(int newZip)
        {
            this.Zip = newZip;
        }
        public string getPhoneNumber()
        {
            return PhoneNumber;
        }
        public void setPhoneNumber(string newPhoneNumber)
        {
            this.PhoneNumber = newPhoneNumber;
        }
        public string getEmailAddress()
        {
            return EmailAddress;
        }
        public void setEmailAddress(string newEmailAddress)
        {
            this.EmailAddress = newEmailAddress;
        }
        public string getDOB()
        {
            return DOB;
        }
        public void setDOB(string newDOB)
        {
            this.DOB = newDOB;
        }
        public string getBio()
        {
            return Bio;
        }
        public void setBio(string newBio)
        {
            this.Bio = newBio;
        }
        public string getTypeID()
        {
            return TypeID;
        }
        public void setTypeID(string newTypeID)
        {
            this.TypeID = newTypeID;
        }
        public string getPicture()
        {
            return picture;
        }
        public void setPicture(string newPicture)
        {
            this.picture = newPicture;
        }
        public static int userSearch(string checkFName, string checkLName)
        {
            try
            {
                string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
                SqlConnection sc = new SqlConnection(constr);
                sc.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = sc;
                command.CommandText = "SELECT * FROM [dbo].[SysUser]";
                command.ExecuteNonQuery();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        if (reader.GetString(1).ToUpper().CompareTo(checkFName.ToUpper()) == 0)
                        {
                            if (reader.GetString(2).ToUpper().CompareTo(checkLName.ToUpper()) == 0)
                            {
                                return reader.GetInt32(0); //If user is found in the SysUser table, returns UserID
                            }
                        }
                    }
                }
                sc.Close();
            }
            catch (Exception e)
            {

            }
            return -1;
        }
        public static void createUser(SysUser newUser)
        {
            string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            SqlConnection sc = new SqlConnection(constr);
            sc.Open();
            SqlCommand command = new SqlCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.Connection = sc;
            int UserPrefix = 0;
            if (newUser.getTypeID() == "Administrator")
            {
                UserPrefix = 1;
            }
            if (newUser.getTypeID() == "Instructor")
            {
                UserPrefix = 2;
            }
            if (newUser.getTypeID() == "Student")
            {
                UserPrefix = 3;
            }
            if (newUser.getTypeID() == "Parent")
            {
                UserPrefix = 4;
            }
            if (newUser.getTypeID() == "Cipher")
            {
                UserPrefix = 5;
            }

            int UserID = Convert.ToInt32(newUser.getUserID(UserPrefix));
            try
            {
                toDateDOB = Convert.ToDateTime(newUser.getDOB());

                command.Parameters.Add("@UserID", SqlDbType.Int).Value = UserID;
                command.Parameters.Add("@FirstName", SqlDbType.VarChar).Value = newUser.getFName();
                command.Parameters.Add("@LastName", SqlDbType.VarChar).Value = newUser.getLName();
                command.Parameters.Add("@BirthDate", SqlDbType.DateTime).Value = toDateDOB;
                command.Parameters.Add("@HomeAddress", SqlDbType.VarChar).Value = newUser.getAddress();
                command.Parameters.Add("@City", SqlDbType.VarChar).Value = newUser.getCity();
                command.Parameters.Add("@HomeState", SqlDbType.VarChar).Value = newUser.getState();
                command.Parameters.Add("@Zip", SqlDbType.Int).Value = newUser.getZip();
                command.Parameters.Add("@Email", SqlDbType.VarChar).Value = newUser.getEmailAddress();
                command.Parameters.Add("@Phone", SqlDbType.VarChar).Value = newUser.getPhoneNumber();
                command.Parameters.Add("@UserType", SqlDbType.VarChar).Value = newUser.getTypeID();
                command.Parameters.Add("@Bio", SqlDbType.VarChar).Value = newUser.getBio();

                command.CommandText = "CreateUser";
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.ToString());
            }
            sc.Close();
        }
        public static void grantUser(SysUser newUser)
        {
            string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            SqlConnection sc = new SqlConnection(constr);
            sc.Open();
            SqlCommand command = new SqlCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.Connection = sc;
            int UserPrefix = 0;
            if (newUser.getTypeID() == "Administrator")
            {
                UserPrefix = 1;
            }
            if (newUser.getTypeID() == "Instructor")
            {
                UserPrefix = 2;
            }
            if (newUser.getTypeID() == "Student")
            {
                UserPrefix = 3;
            }
            if (newUser.getTypeID() == "Parent")
            {
                UserPrefix = 4;
            }
            if (newUser.getTypeID() == "Cipher")
            {
                UserPrefix = 5;
            }

            int UserID = Convert.ToInt32(newUser.getUserID(UserPrefix));
            try
            {
                toDateDOB = Convert.ToDateTime(newUser.getDOB());

                command.Parameters.Add("@UserID", SqlDbType.Int).Value = UserID;
                command.Parameters.Add("@FirstName", SqlDbType.VarChar).Value = newUser.getFName();
                command.Parameters.Add("@LastName", SqlDbType.VarChar).Value = newUser.getLName();
                command.Parameters.Add("@BirthDate", SqlDbType.DateTime).Value = toDateDOB;
                command.Parameters.Add("@Email", SqlDbType.VarChar).Value = newUser.getEmailAddress();
                command.Parameters.Add("@Phone", SqlDbType.VarChar).Value = newUser.getPhoneNumber();
                command.Parameters.Add("@UserType", SqlDbType.VarChar).Value = newUser.getTypeID();

                command.CommandText = "GrantUser";
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.ToString());
            }
            sc.Close();
        }
        public static void editUser(int userID, SysUser u)
        {
            toDateDOB = Convert.ToDateTime(u.getDOB());

            try
            {
                string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
                SqlConnection sc = new SqlConnection(constr);
                sc.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = sc;
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Add("@UserID", SqlDbType.Int).Value = userID;
                command.Parameters.Add("@FirstName", SqlDbType.VarChar).Value = u.getFName();
                command.Parameters.Add("@LastName", SqlDbType.VarChar).Value = u.getLName();
                command.Parameters.Add("@HomeAddress", SqlDbType.VarChar).Value = u.getAddress();
                command.Parameters.Add("@City", SqlDbType.VarChar).Value = u.getCity();
                command.Parameters.Add("@HomeState", SqlDbType.VarChar).Value = u.getState();
                command.Parameters.Add("@Zip", SqlDbType.Int).Value = u.getZip();
                command.Parameters.Add("@Email", SqlDbType.VarChar).Value = u.getEmailAddress();
                command.Parameters.Add("@Phone", SqlDbType.VarChar).Value = u.getPhoneNumber();
                command.Parameters.Add("@UserType", SqlDbType.VarChar).Value = u.getTypeID();
                command.Parameters.Add("@Bio", SqlDbType.VarChar).Value = u.getBio();

                command.CommandText = "UpdateUser";
                command.ExecuteNonQuery();
                sc.Close();
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.ToString());
            }

        }
        public static void deleteUser(string email)
        {
            try
            {
                string sqlQuery = "Delete from [dbo].[aspnet_Membership] where userid in ("
                    + "Select userid from [dbo].[aspnet_UsersInRoles] where userid in ("
                    + "Select userid from [dbo].[aspnet_Users] where username in ("
                    + "Select email from [dbo].[SysUser] where UPPER(Email) = '" + email.ToUpper() + "')))";
                string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
                SqlConnection sc = new SqlConnection(constr);
                sc.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = sc;
                command.CommandText = sqlQuery;
                command.ExecuteNonQuery();
                sqlQuery = "delete from [dbo].[sysuser] where UPPER(email) = '" + email.ToUpper() + "'";
                command.CommandText = sqlQuery;
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {

            }
        }
        public static int getUserByID()
        {
            string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            SqlConnection sc = new SqlConnection(constr);
            sc.Open();
            System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand();
            command.Connection = sc;
            MembershipUser User = Membership.GetUser();
            string UserEmail = User.UserName;
            command.CommandText = "select UserID from sysuser where email = '" + UserEmail + "'";
            command.ExecuteNonQuery();
            SqlDataReader reader = command.ExecuteReader();
            int result = 0;
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    result = reader.GetInt32(0);
                }
            }
            reader.Close();
            return result;
        }
        public static string getUserByName()
        {
            string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            SqlConnection sc = new SqlConnection(constr);
            sc.Open();
            System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand();
            command.Connection = sc;
            MembershipUser User = Membership.GetUser();
            string UserEmail = User.UserName;
            command.CommandText = "select FirstName from sysuser where email = '" + UserEmail + "'";
            command.ExecuteNonQuery();
            SqlDataReader reader = command.ExecuteReader();
            string result = "";
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    result = reader.GetString(0);
                }
            }
            reader.Close();
            return result;
        }
        public static string getBucksBalance()
        {
            string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            SqlConnection sc = new SqlConnection(constr);
            sc.Open();
            System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand();
            command.Connection = sc;
            MembershipUser User = Membership.GetUser();
            string UserEmail = User.UserName;
            command.CommandText = "select BucksBalance from sysuser where email = '" + UserEmail + "'";
            command.ExecuteNonQuery();
            SqlDataReader reader = command.ExecuteReader();
            decimal result = 0.00M;
            string strResult = "";
            if (reader.HasRows)
            {                 
                while (reader.Read())
                {
                    try
                    {
                        result = reader.GetSqlMoney(0).ToDecimal();
                        result = Math.Round(result, 2);
                        strResult = result.ToString();
                    }
                    catch(Exception a)
                    {
                        strResult = "0.00";
                    }
                }
            }
            reader.Close();
            return strResult;
        }
        public static void grantPermissions()
        {

        }
        public static void createRoles()
        {
            Roles.CreateRole("Administrator");
            Roles.CreateRole("Instructor");
            Roles.CreateRole("Student");
            Roles.CreateRole("Parent");
            Roles.CreateRole("Cipher");
            Roles.CreateRole("Applicant");
        }

    }
}
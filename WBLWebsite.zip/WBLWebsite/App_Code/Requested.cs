﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Data;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;

namespace WBLWebsite
{
    public class Requested
    {
        private int ReqUserID;
        private string LName;
        private string FName;
        private string DOB;
        private string ReqType;
        private string PhoneNumber;
        private string EmailAddress;

        static DateTime toDateDOB;

        public Requested()
        {

        }
        public Requested(int ReqUserID, string LName, string FName, string DOB, string ReqType, string PhoneNumber, string EmailAddress)
        {
            setReqUserID(ReqUserID);
            setLName(LName);
            setFName(FName);
            setDOB(DOB);
            setReqType(ReqType);
            setPhoneNumber(PhoneNumber);
            setEmailAddress(EmailAddress);
        }

        //accessors and mutators
        public int getReqUserID()
        {
            return ReqUserID;
        }
        public void setReqUserID(int newReqUserID)
        {
            this.ReqUserID = newReqUserID;
        }
        public String getReqType()
        {
            return ReqType;
        }
        public void setReqType(string newReqType)
        {
            this.ReqType = newReqType;
        }
        public string getFName()
        {
            return FName;
        }
        public void setFName(string newFName)
        {
            this.FName = newFName;
        }
        public string getLName()
        {
            return LName;
        }
        public void setLName(string newLName)
        {
            this.LName = newLName;
        }
        public string getPhoneNumber()
        {
            return PhoneNumber;
        }
        public void setPhoneNumber(string newPhoneNumber)
        {
            this.PhoneNumber = newPhoneNumber;
        }
        public string getEmailAddress()
        {
            return EmailAddress;
        }
        public void setEmailAddress(string newEmailAddress)
        {
            this.EmailAddress = newEmailAddress;
        }
        public string getDOB()
        {
            return DOB;
        }
        public void setDOB(string newDOB)
        {
            this.DOB = newDOB;
        }
        public static int userSearch(string checkFName, string checkLName)
        {
            try
            {
                string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
                SqlConnection sc = new SqlConnection(constr);
                sc.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = sc;
                command.CommandText = "SELECT * FROM [dbo].[Requested]";
                command.ExecuteNonQuery();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        if (reader.GetString(1).ToUpper().CompareTo(checkFName.ToUpper()) == 0)
                        {
                            if (reader.GetString(2).ToUpper().CompareTo(checkLName.ToUpper()) == 0)
                            {
                                return reader.GetInt32(0); //If user is found in the SysUser table, returns UserID
                            }
                        }
                    }
                }
                sc.Close();
            }
            catch (Exception e)
            {

            }
            return -1;
        }
        public static void createRequested(Requested newUser)
        {
            string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            SqlConnection sc = new SqlConnection(constr);
            sc.Open();
            SqlCommand command = new SqlCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.Connection = sc;
            try
            {
                toDateDOB = Convert.ToDateTime(newUser.getDOB());

                command.Parameters.Add("@RequestedID", SqlDbType.Int).Value = newUser.getReqUserID();
                command.Parameters.Add("@FirstName", SqlDbType.VarChar).Value = newUser.getFName();
                command.Parameters.Add("@LastName", SqlDbType.VarChar).Value = newUser.getLName();
                command.Parameters.Add("@Email", SqlDbType.VarChar).Value = newUser.getEmailAddress();
                command.Parameters.Add("@ReqType", SqlDbType.VarChar).Value = newUser.getReqType();            
                command.Parameters.Add("@Phone", SqlDbType.VarChar).Value = newUser.getPhoneNumber();
                command.Parameters.Add("@BirthDate", SqlDbType.DateTime).Value = toDateDOB;
                command.CommandText = "CreateReqUser";
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.ToString());
            }
            sc.Close();
        }
        public static void deleteUser(int userID)
        {
            try
            {
                string sqlQuery = "";
                string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
                SqlConnection sc = new SqlConnection(constr);
                sc.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = sc;
                sqlQuery = "Delete from requested where RequestedID = " + userID;
                command.CommandText = sqlQuery;
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {

            }
        }
        public static int checkRequestedID()
        {
            int ID = 0;
            string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            string sqlQuery = "";
            SqlConnection sc = new SqlConnection(constr);
            sc.Open();
            SqlCommand command = new SqlCommand();
            command.Connection = sc;
            sqlQuery="select RequestedID from requested order by RequestedID";
            command.CommandText = sqlQuery;
            command.ExecuteNonQuery();

            SqlDataReader reader = command.ExecuteReader();

            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    ID = reader.GetInt32(0);
                }
            }
            ID++;
            sc.Close();
            return ID;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Data;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;

namespace WBLWebsite
{
    public class Class
    {

        private int classID;
        private string className;
        private string classDescription;
        private string classTime;
        private string classLocation;
        private string startDate;
        private string endDate;
        private string classInstructor;

        public Class()
        {
            setClassID(0);
            setClassName("");
            setClassDescription("");
            setClassTime("");
            setClassLocation("");
            setStartDate("");
            setEndDate("");
            setClassInstructor("");
        }

        public Class(int newClassID, string newClassName, string newClassDescription, string newClassTime, string newClassLocation, string newClassStartDate, string newClassEndDate, string newClassInstructor)
        {
            setClassID(newClassID);
            setClassName(newClassName);
            setClassDescription(newClassDescription);
            setClassTime(newClassTime);
            setClassLocation(newClassLocation);
            setStartDate(newClassStartDate);
            setEndDate(newClassEndDate);
            setClassInstructor(newClassInstructor);
        }
        public static int checkClassID()
        {
            int ID = 0;
            string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            string sqlQuery = "";
            SqlConnection sc = new SqlConnection(constr);
            sc.Open();
            SqlCommand command = new SqlCommand();
            command.Connection = sc;
            sqlQuery = "select ClassID from class order by ClassID";
            command.CommandText = sqlQuery;
            command.ExecuteNonQuery();

            SqlDataReader reader = command.ExecuteReader();

            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    ID = reader.GetInt32(0);
                }
            }
            ID++;
            sc.Close();
            return ID;
        }

        public int getClassID()
        {
            return classID;
        }
        public void setClassID(int newClassID)
        {
            this.classID = newClassID;
        }
        public string getClassName()
        {
            return className;
        }
        public void setClassName(string newClassName)
        {
            this.className = newClassName;
        }
        public string getClassDescription()
        {
            return classDescription;
        }
        public void setClassDescription(string newClassDescription)
        {
            this.classDescription = newClassDescription;
        }
        public string getClassInstructor()
        {
            return classInstructor;
        }
        public void setClassInstructor(string newClassInstructor)
        {
            this.classInstructor = newClassInstructor;
        }
        public string getStartDate()
        {
            return startDate;
        }
        public void setStartDate(string newStartDate)
        {
            this.startDate = newStartDate;
        }
        public string getEndDate()
        {
            return endDate;
        }
        public void setEndDate(string newEndDate)
        {
            this.endDate = newEndDate;
        }
        public string getClassLocation()
        {
            return classLocation;
        }
        public void setClassLocation(string newClassLocation)
        {
            this.classLocation = newClassLocation;
        }
        public string getClassTime()
        {
            return classTime;
        }
        public void setClassTime(string newClassTime)
        {
            this.classTime = newClassTime;
        }
    }
}
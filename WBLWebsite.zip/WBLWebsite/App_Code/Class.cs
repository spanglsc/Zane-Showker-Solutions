﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WBLWebsite
{
    public class Class
    {

        private string classID;
        private string className;
        private string classDescription;
        private string classTime;
        private string classLocation;
        private string startDate;
        private string endDate;
        private string classInstructor;



        public Class()
        {
            setClassID("");
            setClassName("");
            setClassDescription("");
            setClassTime("");
            setClassLocation("");
            setStartDate("");
            setEndDate("");
            setClassInstructor("");
        }

        public Class(string newClassID, string newClassName, string newClassDescription, string newClassTime, string newClassLocation, string newClassStartDate, string newClassEndDate, string newClassInstructor)
        {
            setClassID(newClassID);
            setClassName(newClassName);
            setClassDescription(newClassDescription);
            setClassTime(newClassTime);
            setClassLocation(newClassLocation);
            setStartDate(newClassStartDate);
            setEndDate(newClassEndDate);
            setClassInstructor(newClassInstructor);

        }



        public string getClassID()
        {
            return classID;
        }
        public void setClassID(string newClassID)
        {
            this.classID = newClassID;
        }
        public string getClassName()
        {
            return className;
        }
        public void setClassName(string newClassName)
        {
            this.className = newClassName;
        }
        public string getClassDescription()
        {
            return classDescription;
        }
        public void setClassDescription(string newClassDescription)
        {
            this.classDescription = newClassDescription;
        }
        public string getClassInstructor()
        {
            return classInstructor;
        }
        public void setClassInstructor(string newClassInstructor)
        {
            this.classInstructor = newClassInstructor;
        }
        public string getStartDate()
        {
            return startDate;
        }
        public void setStartDate(string newStartDate)
        {
            this.startDate = newStartDate;
        }
        public string getEndDate()
        {
            return endDate;
        }
        public void setEndDate(string newEndDate)
        {
            this.endDate = newEndDate;
        }
        public string getClassLocation()
        {
            return classLocation;
        }
        public void setClassLocation(string newClassLocation)
        {
            this.classLocation = newClassLocation;
        }
        public string getClassTime()
        {
            return classTime;
        }
        public void setClassTime(string newClassTime)
        {
            this.classTime = newClassTime;
        }



    }
}
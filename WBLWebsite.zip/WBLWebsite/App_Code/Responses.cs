﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Data;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;

namespace WBLWebsite
{
    public class Responses
    {
        private int ResponseID;
        private int ForumID;
        private int UserID;
        private String ResponseSummary;
        private string date;
        private static Boolean CorrectForumInfo = false;

        public Responses()
        {

        }

        public Responses(int rID, int fID, int uID, String summary, DateTime date)
        {
            setResponseID(rID);
            setForumID(fID);
            setUserID(uID);
            setResponseSummary(summary);            
        }
        public Responses(int fID, int uID, String summary, string date)
        {
            try
            {
                setForumID(fID);
                setUserID(uID);
                setResponseSummary(summary);
                setDate(date);
                CorrectForumInfo = true;
            }
            catch(Exception a)
            {

            }
        }

        public static void createResponse(Responses r)
        {
            DateTime toDateTime;
            if (CorrectForumInfo == true)
            {
                //Connect to the database
                System.Data.SqlClient.SqlConnection sc = new System.Data.SqlClient.SqlConnection();
                sc.ConnectionString = @"Server =LOCALHOST; Database = WBL;Trusted_Connection=Yes;";
                sc.Open();

                SqlCommand insert = new SqlCommand();
                insert.CommandType = System.Data.CommandType.Text;
                insert.Connection = sc;

                

                //Need to figure out what attributes we need in this table
                try
                {
                    toDateTime = Convert.ToDateTime(r.getDate());
                    insert.Parameters.Add("@Date", SqlDbType.DateTime).Value = toDateTime;
                    insert.CommandText = "insert into Responses(Response, ResponseDate, ForumID, UserID) values ('"
                        + r.getResponseSummary() + "',"
                        + " @Date,'"
                        + r.getForumID() + "','"
                        + r.getUserID() + "')";

                    insert.ExecuteNonQuery();

                    sc.Close();
                }
                catch(Exception a)
                {

                }
            }
        }
        public void editResponse(int rID, String summary)
        {
            setForumID(rID);
            setResponseSummary(summary);

            //If all info is correct write it to the database
            if (CorrectForumInfo == true)
            {

                //Connect to the database
                System.Data.SqlClient.SqlConnection sc = new System.Data.SqlClient.SqlConnection();
                sc.ConnectionString = @"Server =LOCALHOST; Database = WBL;Trusted_Connection=Yes;";
                sc.Open();

                SqlCommand insert = new SqlCommand();
                insert.CommandType = System.Data.CommandType.Text;
                insert.Connection = sc;



                //Need to figure out what attributes we need in this table

                insert.CommandText = "update Responses set " +
                    "Response ='" + getResponseSummary() +
                    "where ResponseID = '" + getResponseID();


                sc.Close();

                //Label saying that the edit was written to the database
            }
        }



        public static void deleteResponse(int ID)
        {
            //Connect to the database
            System.Data.SqlClient.SqlConnection sc = new System.Data.SqlClient.SqlConnection();
            sc.ConnectionString = @"Server =LOCALHOST; Database = WBL;Trusted_Connection=Yes;";
            sc.Open();

            SqlCommand insert = new SqlCommand();
            insert.CommandType = System.Data.CommandType.Text;
            insert.Connection = sc;

            insert.CommandText = "delete from Responses where ResponseID = " + ID;
            insert.ExecuteNonQuery();
            sc.Close();

            //Message says that the delete worked
        }


        public void setResponseID(int newResponseID)
        {
            //We sould have this auto populate
        }

        public void setForumID(int newForumID)
        {

            //Should this be pulled automaticly

            if (newForumID == null)
            {
                //Display error for not having a summary
                CorrectForumInfo = false;
            }
            else
            {
                ForumID = newForumID;
                CorrectForumInfo = true;
            }
        }


        public void setUserID(int newUserID)
        {
            //User entering the response
            UserID = newUserID;
        }
        public void setDate(string newDate)
        {
            date = newDate;
        }


        public void setResponseSummary(String newResponseSummary)
        {
            if (newResponseSummary.Length > 200)
            {
                //Display Error for summary being too long
                CorrectForumInfo = false;
            }
            else
            {
                ResponseSummary = newResponseSummary;
            }
        }



        //All Get Methods
        public int getResponseID()
        {
            return ResponseID;
        }
        public int getForumID()
        {
            return ForumID;
        }
        public int getUserID()
        {
            return UserID;
        }
        public String getResponseSummary()
        {
            return ResponseSummary;
        }
        public string getDate()
        {
            return date;
        }


    }
}
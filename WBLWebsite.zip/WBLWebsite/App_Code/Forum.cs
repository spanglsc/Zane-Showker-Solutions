﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Data;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;

namespace WBLWebsite
{
    public class Forum
    {
        private int ForumID;
        private String ForumTitle;
        private String ForumSummary;
        private DateTime ForumDate;
        private int UserID;
        private int ForumCount = 1;
        private static Boolean CorrectForumInfo = false;

        public Forum()
        {

        }

        public Forum(int ID,String Title, String Summary, DateTime Date, int UserID)
        {
            setForumID(ID);
            setForumTitle(Title);
            setForumSummary(Summary);
            setForumDate(Date);
            setUserID(UserID);
        }
        public static void createForum(Forum f)
        {
            //If all info is correct write it to the database
            if (CorrectForumInfo == true)
            {
                MembershipUser u = Membership.GetUser();
                string user = u.UserName;
                DateTime today = DateTime.Now;
                //Connect to the database
                System.Data.SqlClient.SqlConnection sc = new System.Data.SqlClient.SqlConnection();
                sc.ConnectionString = @"Server =LocalHost; Database = WBL;Trusted_Connection=Yes;";
                sc.Open();

                SqlCommand insert = new SqlCommand();
                insert.CommandType = System.Data.CommandType.Text;
                insert.Connection = sc;

                insert.CommandText = "insert into Forums values ('"
                    + f.getForumID() + "','"
                    + f.getForumTitle() + "','"
                    + f.getForumSummary() + "','"
                    + today + "','"
                    + SysUser.getUserByID() + "')";

                insert.ExecuteNonQuery();

                sc.Close();
            }
        }

        public static void editForum(Forum f)
        {
            //If all info is correct write it to the database
            if (CorrectForumInfo == true)
            {
                //Connect to the database
                System.Data.SqlClient.SqlConnection sc = new System.Data.SqlClient.SqlConnection();
                sc.ConnectionString = @"Server =LocalHost; Database = WBL;Trusted_Connection=Yes;";
                sc.Open();

                SqlCommand insert = new SqlCommand();
                insert.CommandType = System.Data.CommandType.Text;
                insert.Connection = sc;

                insert.CommandText = "update Forum set " +
                    "Title ='" + f.getForumTitle() + "','" +
                    "Summary ='" + f.getForumSummary() + "','" +
                    "ForumDate ='" + f.getForumDate() +
                    "UserID ='" + f.getUserID() +
                    "where ForumID = '" + f.getForumID();

                sc.Close();

                //Label saying that the edit was written to the database
            }
        }

        public static void deleteForum(int ID)
        {
            
                //Connect to the database
                System.Data.SqlClient.SqlConnection sc = new System.Data.SqlClient.SqlConnection();
                sc.ConnectionString = @"Server =LocalHost; Database = WBL;Trusted_Connection=Yes;";
                sc.Open();

                SqlCommand insert = new SqlCommand();
                insert.CommandType = System.Data.CommandType.Text;
                insert.Connection = sc;
            try
            {
                insert.CommandText = "delete from Forums where ForumID = " + ID;
                insert.ExecuteNonQuery();
            }
            catch(Exception e)
            {

            }
            sc.Close();

            //Message says that the delete worked
        }

        public void setForumID(int newForumID)
        {
            //If Forum ID field is blank, one is assigned
            if (newForumID == 0)
            {
                ForumID = ForumCount++;
            }
            ForumID = newForumID;
            CorrectForumInfo = true;        //Correct Info was entered
        }


        public void setForumTitle(String newForumTitle)
        {
            if (newForumTitle == null)
            {
                //Display error for not having a title
                CorrectForumInfo = false;
            }
            else if (newForumTitle.Length > 50)
            {
                //Display error for title being too long
                CorrectForumInfo = false;
            }
            else
            {
                ForumTitle = newForumTitle;
                CorrectForumInfo = true;        //Correct Info was entered
            }
        }



        public void setForumSummary(String newForumSummary)
        {
            if (newForumSummary == null)
            {
                //Display error for not having a title
                CorrectForumInfo = false;
            }
            else if (newForumSummary.Length > 100)
            {
                //Display error for summary being too long
                CorrectForumInfo = false;
            }
            else
            {
                ForumSummary = newForumSummary;
                CorrectForumInfo = true;        //Correct Info was entered
            }
        }


        public void setForumDate(DateTime newForumDate)
        {
            if (newForumDate == null)
            {
                //Display error for not having a title
                CorrectForumInfo = false;
            }
            else
            {
                ForumDate = newForumDate;
                CorrectForumInfo = true;        //Correct Info was entered
            }
        }

        public void setUserID(int newUserID)
        {
            if (newUserID == null)
            {
                //Display error for not having a title
                CorrectForumInfo = false;
            }
            else
            {
                UserID = newUserID;
                CorrectForumInfo = true;        //Correct Info was entered
            }
        }



        //All Get Methods
        public int getForumID()
        {
            int ID = 0;
            string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            string sqlQuery = "";
            SqlConnection sc = new SqlConnection(constr);
            sc.Open();
            SqlCommand command = new SqlCommand();
            command.Connection = sc;
            sqlQuery = "select ForumID from Forums order by ForumID";
            command.CommandText = sqlQuery;
            command.ExecuteNonQuery();

            SqlDataReader reader = command.ExecuteReader();

            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    ID = reader.GetInt32(0);
                }
            }
            ID++;
            sc.Close();
            return ID;
        }

        public String getForumTitle()
        {
            return ForumTitle;
        }
        public String getForumSummary()
        {
            return ForumSummary;
        }
        public DateTime getForumDate()
        {
            return ForumDate;
        }
        public int getUserID()
        {
            return UserID;
        }
    }
}
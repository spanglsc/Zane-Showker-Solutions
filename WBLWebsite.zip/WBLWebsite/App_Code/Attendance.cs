﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WBLWebsite
{
    class Attendance
    {
        private int userID;
        private int classID;
        private DateTime date;
        private Attendance()
        {
        }
        private Attendance(int userID, int classID, DateTime date)
        {
        //test
        }
    }
}

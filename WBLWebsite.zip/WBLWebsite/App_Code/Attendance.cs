﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Data;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;

namespace WBLWebsite
{
    public class Attendance
    {

        public Attendance()
        {
        }

        public static string takeAttendance(int classID, int userID, string date)
        {
            //Connect to the database
            System.Data.SqlClient.SqlConnection sc = new System.Data.SqlClient.SqlConnection();
            sc.ConnectionString = @"Server =LOCALHOST; Database = WBL;Trusted_Connection=Yes;";
            sc.Open();

            DateTime today = DateTime.Now;
            SqlCommand insert = new SqlCommand();
            insert.CommandType = System.Data.CommandType.Text;
            insert.Connection = sc;

            insert.CommandText = "insert into Attendance values ('"
                + classID + "','"
                + userID + "','"
                + today + "','" + "true')";
            try
            {
                insert.ExecuteNonQuery();
                sc.Close();
                return "Success!";
            }
            catch (Exception e)
            {
                sc.Close();
                return "You can only submit one attendance sheet per class per day.";                
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Security;

namespace WBLWebsite.AdminPages
{
    public partial class Portfolio : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string email = (string)(Session["Email"]);
                if (email != null)
                {
                    NamePortfolio.Text = SysUser.getUserByName(email);
                    BindGrid();
                }
                else
                {
                    Server.Transfer("/UserPages/Default.aspx");
                }
            }
        }
        private void BindGrid()
        {
            string email = (string)(Session["Email"]);
            string strConnString = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(strConnString))
            {
                using (SqlCommand cmd1 = new SqlCommand())
                {
                    cmd1.CommandText = "select PortfolioID, Name, ContentType from Portfolio where ContentType = 'video/mp4' AND UserID in (select UserID from SysUser where email = '" + email + "')";
                    cmd1.Connection = con;
                    con.Open();
                    DataList1.DataSource = cmd1.ExecuteReader();
                    DataList1.DataBind();
                    con.Close();
                }
                using (SqlCommand cmd2 = new SqlCommand())
                {
                    cmd2.CommandText = "select PortfolioID, Name, ContentType from Portfolio where ContentType = 'audio/mp3' AND UserID in (select UserID from SysUser where email = '" + email + "')";
                    cmd2.Connection = con;
                    con.Open();
                    GridView1.DataSource = cmd2.ExecuteReader();
                    GridView1.DataBind();
                    con.Close();
                }
                using (SqlCommand cmd3 = new SqlCommand())
                {
                    cmd3.CommandText = "select PortfolioID, Name, ContentType from Portfolio where ContentType = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' OR ContentType = 'application/pdf' OR ContentType = 'image/jpeg' OR ContentType = 'image/png' AND UserID in (select UserID from SysUser where email = '" + email + "')";
                    cmd3.Connection = con;
                    con.Open();
                    GridView2.DataSource = cmd3.ExecuteReader();
                    GridView2.DataBind();
                    con.Close();
                }
            }
        }
        protected void DownloadFile(object sender, EventArgs e)
        {
            int id = int.Parse((sender as LinkButton).CommandArgument);
            byte[] bytes;
            string fileName, contentType;
            string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = "select Name, Data, ContentType from Portfolio where PortfolioID =@Id";
                    cmd.Parameters.AddWithValue("@Id", id);
                    cmd.Connection = con;
                    con.Open();
                    using (SqlDataReader sdr = cmd.ExecuteReader())
                    {
                        sdr.Read();
                        bytes = (byte[])sdr["Data"];
                        contentType = sdr["ContentType"].ToString();
                        fileName = sdr["Name"].ToString();
                    }
                    con.Close();
                }
            }
            Response.Clear();
            Response.Buffer = true;
            Response.Charset = "";
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.ContentType = contentType;
            Response.AppendHeader("Content-Disposition", "attachment; filename=" + fileName);
            Response.BinaryWrite(bytes);
            Response.Flush();
            Response.End();
        }
        protected void btnUpload_Click(object sender, EventArgs e)
        {
            MembershipUser User = Membership.GetUser();
            string UserEmail = User.UserName;

            if (FileUpload1.HasFile)
            {
                String a = Path.GetFileName(FileUpload1.PostedFile.FileName);
                String f = Path.GetExtension(a);
                f = f.ToLower();

                string[] acceptedFileTypes = new string[6];
                acceptedFileTypes[0] = ".pdf";
                acceptedFileTypes[1] = ".docx";
                acceptedFileTypes[2] = ".jpg";
                acceptedFileTypes[3] = ".png";
                acceptedFileTypes[4] = ".mp3";
                acceptedFileTypes[5] = ".mp4";
                for (int i = 0; i <= 5; i++)
                {
                    if (f == acceptedFileTypes[i])
                    {
                        int fileSize = FileUpload1.PostedFile.ContentLength;
                        if (fileSize < 1000000000)
                        {
                            string filename = Path.GetFileName(FileUpload1.PostedFile.FileName);
                            string contentType = FileUpload1.PostedFile.ContentType;
                            using (Stream fs = FileUpload1.PostedFile.InputStream)
                            {
                                using (BinaryReader br = new BinaryReader(fs))
                                {
                                    byte[] bytes = br.ReadBytes((Int32)fs.Length);
                                    string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
                                    SqlConnection sc = new SqlConnection(constr);
                                    sc.Open();
                                    System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand();
                                    command.Connection = sc;
                                    command.CommandText = "select UserID from sysuser where email = '" + UserEmail + "'";
                                    command.ExecuteNonQuery();
                                    SqlDataReader reader = command.ExecuteReader();
                                    int result = 0;
                                    if (reader.HasRows)
                                    {
                                        while (reader.Read())
                                        {
                                            result = reader.GetInt32(0);
                                        }
                                    }
                                    reader.Close();
                                    using (SqlConnection con = new SqlConnection(constr))
                                    {
                                        string query = "insert into Portfolio(UserID, Name, ContentType, Data) values (@result, @Name, @ContentType, @Data)";
                                        using (SqlCommand cmd = new SqlCommand(query))
                                        {
                                            cmd.Connection = con;
                                            cmd.Parameters.AddWithValue("@result", result);
                                            cmd.Parameters.AddWithValue("@Name", filename);
                                            cmd.Parameters.AddWithValue("@ContentType", contentType);
                                            cmd.Parameters.AddWithValue("@Data", bytes);
                                            con.Open();
                                            cmd.ExecuteNonQuery();
                                            con.Close();
                                        }
                                    }
                                }
                            }
                            Response.Redirect(Request.Url.AbsoluteUri);

                            using (BinaryReader br = new BinaryReader(FileUpload1.PostedFile.InputStream))
                            {
                                byte[] bytes = br.ReadBytes((int)FileUpload1.PostedFile.InputStream.Length);
                                string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
                                SqlConnection sc = new SqlConnection(constr);
                                sc.Open();
                                System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand();
                                command.Connection = sc;
                                command.CommandText = "select UserID from sysuser where email = '" + UserEmail + "'";
                                command.ExecuteNonQuery();
                                SqlDataReader reader = command.ExecuteReader();
                                int result = 0;
                                if (reader.HasRows)
                                {
                                    while (reader.Read())
                                    {
                                        result = reader.GetInt32(0);
                                    }
                                }
                                reader.Close();
                                command.Parameters.AddWithValue("@result", result);

                                command.ExecuteNonQuery();
                                using (SqlConnection con = new SqlConnection(constr))
                                {
                                    using (SqlCommand cmd = new SqlCommand())
                                    {
                                        if (f == ".mp4")
                                        {
                                            cmd.CommandText = "insert into Portfolio(UserID, Name, ContentType, Data) values (@result, @Name, @ContentType, @Data)";
                                            cmd.Parameters.AddWithValue("@Name", Path.GetFileName(FileUpload1.PostedFile.FileName));
                                            cmd.Parameters.AddWithValue("@ContentType", "video/mp4");
                                            cmd.Parameters.AddWithValue("@Data", bytes);
                                            cmd.Connection = con;
                                            con.Open();
                                            cmd.ExecuteNonQuery();
                                            con.Close();
                                        }
                                        if (f == ".mp3")
                                        {
                                            cmd.CommandText = "insert into Portfolio(UserID, Name, ContentType, Data) values (@result, @Name, @ContentType, @Data)";
                                            cmd.Parameters.AddWithValue("@Name", Path.GetFileName(FileUpload1.PostedFile.FileName));
                                            cmd.Parameters.AddWithValue("@ContentType", "audio/mpeg3");
                                            cmd.Parameters.AddWithValue("@Data", bytes);
                                            cmd.Connection = con;
                                            con.Open();
                                            cmd.ExecuteNonQuery();
                                            con.Close();
                                        }
                                    }
                                }
                            }
                            Response.Redirect(Request.Url.AbsoluteUri);
                        }
                        else
                        {
                            UploadStatus.Text = "You cannot upload files larger than 1GB";
                        }
                    }
                    else {
                        UploadStatus.Text = "You can only upload .docx, .pdf, .jpg, .png, .mp3, or .mp4 file types";
                    }
                }
            }
            else
            {
                UploadStatus.Text = "You did not specify a file to upload";
            }
        }
        protected void DeleteFile(object sender, EventArgs e)
        {
            int id = int.Parse((sender as LinkButton).CommandArgument);
            string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = "delete from dbo.Portfolio where PortfolioID = @Id";
                    cmd.Parameters.AddWithValue("@Id", id);
                    cmd.Connection = con;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    BindGrid();
                }
            }
        }
    }
}
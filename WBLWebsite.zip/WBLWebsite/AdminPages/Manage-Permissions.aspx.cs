﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;

namespace WBLWebsite
{
    public partial class Manage_Permissions : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            /*DataTable test = this.GetData("select CAST(RequestedID as varchar(5)), FirstName, LastName, Email, ReqType from Requested");
            GridView1.DataSource = test;
            // Displays the Employee Table
            DataTable requestedUsers = this.GetData("select RequestedID, FirstName, LastName, Email, ReqType from Requested");

            StringBuilder html = new StringBuilder();

            html.Append("<div class='container data-container requested-users-table'>");
            html.Append("<h2>Requested Users</h2>");
            html.Append("<table class='table table-striped'>");

            html.Append("<thead>");
            html.Append("<tr>");
            foreach (DataColumn column in requestedUsers.Columns)
            {
                html.Append("<th>");
                html.Append(column.ColumnName);
                html.Append("</th>");
            }
            html.Append("<th>");
            html.Append("Permissions");
            html.Append("</tr>");

            foreach (DataRow row in requestedUsers.Rows)
            {
                int ID = Convert.ToInt32(row.ItemArray[0]);
                html.Append("<tr id='row" + ID.ToString() + "'>");
                foreach (DataColumn column in requestedUsers.Columns)
                {
                    string headerName = Convert.ToString(column.ColumnName);
                    if (headerName == "ReqType")
                    {
                        html.Append("<td><select runat='server' ID='selManageUserType" + ID.ToString() + "' name='selectManageUserType' class='form-control'>" 
                            + "<option>Student</option>" 
                            + "<option>Instructor</option>"
                            + "<option>Parent</option>"
                            + "<option>Cipher</option>"
                            + "</select>");
                        html.Append("</td>");
                        html.Append("<td><button runat='server' ID='btnAllow" + ID.ToString() + "' class='btn btn-primary' Text='Allow' onserverClick='GrantPermissions_Click'/>Allow</td>");
                        html.Append("<td><button runat='server' ID='btnDeny" + ID.ToString() + "' class='btn btn-primary' Text='Deny' onserverClick='DenyPermissions_Click'/>Deny</td>");
                    }
                    else
                    {
                        html.Append("<td>");
                        html.Append(row[column.ColumnName]);
                        html.Append("</td>");
                    }
                }
                html.Append("</tr>");
            }
            html.Append("</thead>");
            html.Append("</table>");
            html.Append("</div>");

            RequestedUsers.Controls.Add(new Literal { Text = html.ToString() });*/
        }
        private DataTable GetData(String sqlQuery)
        {
            string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand(sqlQuery))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter())
                    {
                        cmd.Connection = con;
                        sda.SelectCommand = cmd;
                        using (DataTable dt = new DataTable())
                        {
                            sda.Fill(dt);
                            return dt;
                        }
                    }
                }
            }
        }
        public void GrantPermissions_Click(object sender, EventArgs e)
        {
            Button button = sender as Button;
        }
        protected void test_Click(object sender, EventArgs e)
        {
            Button button = sender as Button;
            string test = button.Attributes.ToString();
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow row = GridView1.SelectedRow;
            int ID = Convert.ToInt32(row.Cells[1].Text);
            SysUser.grantUser(new SysUser(row.Cells[3].Text, row.Cells[2].Text, row.Cells[7].Text, row.Cells[6].Text, row.Cells[4].Text, row.Cells[5].Text));
            Requested.deleteUser(ID);
            Response.Redirect(Request.RawUrl);
        }
    }
}

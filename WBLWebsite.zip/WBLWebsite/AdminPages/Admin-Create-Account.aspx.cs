﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WBLWebsite.AdminPages
{
    public partial class Admin_Create_Account : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void btnAdminCreateAccount_Click(object sender, EventArgs e)
        {
            try
            {
                Membership.CreateUser(txtAdminCreateEmail.Text, txtAdminCreatePass.Text);
                SysUser.createUser(new SysUser(txtAdminCreateLName.Text, txtAdminCreateFName.Text, "01/01/2016", "", "", "", 20001, "", txtAdminCreateEmail.Text, "", selAdminUserType.Value.ToString(), ""));
                Roles.AddUserToRole(txtAdminCreateEmail.Text, selAdminUserType.Value.ToString());
                txtAdminCreateFName.Text = "";
                txtAdminCreateLName.Text = "";
                txtAdminCreateEmail.Text = "";
                txtAdminCreatePass.Text = "";
                txtAdminCreateConf.Text = "";
                selAdminUserType.SelectedIndex = 0;
            }
            catch (Exception a)
            {

            }
        }
    }
}
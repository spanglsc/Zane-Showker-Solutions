﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WBLWebsite.AdminPages
{
    public partial class Admin_Create_Account : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void btnAdminCreateAccount_Click(object sender, EventArgs e)
        {
            try
            {
                Membership.CreateUser(txtAdminCreateEmail.Text, txtAdminCreatePass.Text);
                SysUser.createUser(new SysUser(txtAdminCreateLName.Text, txtAdminCreateFName.Text, "01/01/2016", "admin", "dsfawdfa", "dsfawdfa", 19380, "dfsdfdsf", txtAdminCreateEmail.Text, "dsfawdfa", selAdminUserType.Value.ToString(), "fgsdfg"));
                Roles.AddUserToRole(txtAdminCreateEmail.Text, selAdminUserType.Value.ToString());
                txtAdminCreateFName.Text = "";
                txtAdminCreateLName.Text = "";
                txtAdminCreateEmail.Text = "";
                txtAdminCreatePass.Text = "";
                txtAdminCreateConf.Text = "";
                selAdminUserType.SelectedIndex = 0;
            }
            catch (Exception a)
            {

            }
        }
        protected void btnLogout_Click(object sender, EventArgs e)
        {
            FormsAuthentication.SignOut();
            Session.Abandon();

            // clear authentication cookie
            HttpCookie cookie1 = new HttpCookie(FormsAuthentication.FormsCookieName, "");
            cookie1.Expires = DateTime.Now.AddYears(-1);
            Response.Cookies.Add(cookie1);
            FormsAuthentication.RedirectToLoginPage();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Web.Security;

namespace WBLWebsite
{
    public partial class AdminForums : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

            }
        }
        protected void Page_Init(object sender, EventArgs e)
        {
            populateForums();
        }
        public void populateForums()
        {
            string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            SqlConnection sc = new SqlConnection(constr);
            sc.Open();
            System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand();
            command.Connection = sc;
            command.CommandText = "select * from Forums order by ForumID";
            command.ExecuteNonQuery();
            SqlDataReader reader = command.ExecuteReader();
            int ID = 0;
            int count = 0;
            string title = "";
            string summary = "";
            DateTime date;
            int UserID = 0;
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    count++;
                }
            }
            int i = 0;
            Forum[] forumArray = new Forum[count];
            reader.Close();
            SqlDataReader IDreader = command.ExecuteReader();
            if (IDreader.HasRows)
            {
                while (IDreader.Read())
                {
                    
                    title = IDreader.GetString(1);
                    summary = IDreader.GetString(2);
                    date = IDreader.GetDateTime(3);
                    UserID = IDreader.GetInt32(4);
                    forumArray[i] = new Forum(IDreader.GetInt32(0), title, summary, date, UserID);
                    i++;
                }
            }
            IDreader.Close();
            sc.Close();
            for (int j = 0; j < forumArray.Length; j++)
            {
                try
                {
                    try
                    {
                        sc.Open();
                    }
                    catch (Exception a)
                    {

                    }
                    command.Connection = sc;
                    command.CommandText = "select Responses.*, CONCAT(SysUser.FirstName,' ',SysUser.LastName) as 'Name' from Responses, SysUser Where Responses.ForumID = '" + forumArray[j].getForumID() + "' And SysUser.UserID = Responses.UserID";
                    command.ExecuteNonQuery();
                    SqlDataReader responseReader = command.ExecuteReader();
                    int countResponse = 0;
                    if (responseReader.HasRows)
                    {
                        while (responseReader.Read())
                        {
                            countResponse++;
                        }
                    }
                    responseReader.Close();
                    sc.Close();
                    int k = 0;

                    Literal titleBefore = new Literal();
                    titleBefore.Text = "<div class='row discussion discussion" + forumArray[j].getForumID() + "'><h2>";
                    Literal titleAfter = new Literal();
                    titleAfter.Text = "</h2>";
                    Literal summaryBefore = new Literal();
                    summaryBefore.Text = "<h4><small>";
                    Literal summaryAfter = new Literal();
                    summaryAfter.Text = "</h4></small></div>";
                    Label discussionTitle = new Label();
                    discussionTitle.ID = "Discussion" + forumArray[j].getForumID();
                    discussionTitle.Text = forumArray[j].getForumTitle();
                    Label discussionSummary = new Label();
                    discussionSummary.Text = forumArray[j].getForumSummary();
                    Button btnDeleteForum = new Button();
                    btnDeleteForum.ID = "btnDeleteForum" + forumArray[j].getForumID();
                    btnDeleteForum.Text = "Delete";
                    btnDeleteForum.CssClass = "btn btn-danger right";
                    btnDeleteForum.Click += new EventHandler(this.deleteForum_Click);


                    Literal responseBefore = new Literal();
                    responseBefore.Text = "<div class='row'><div class='discussion-content toggle-discussion" + forumArray[j].getForumID() + "'>"
                        + "<div class='col-lg-1'>"
                        + "</div>"
                        + "<div class='col-lg-6'>";
                    discussionPlaceHolder.Controls.Add(titleBefore);
                    discussionPlaceHolder.Controls.Add(discussionTitle);
                    discussionPlaceHolder.Controls.Add(titleAfter);
                    discussionPlaceHolder.Controls.Add(btnDeleteForum);
                    discussionPlaceHolder.Controls.Add(summaryBefore);
                    discussionPlaceHolder.Controls.Add(discussionSummary);
                    discussionPlaceHolder.Controls.Add(summaryAfter);
                    discussionPlaceHolder.Controls.Add(responseBefore);
              
                    try
                    {
                        sc.ConnectionString = constr;
                        sc.Open();
                    }
                    catch (Exception b)
                    {

                    }
                    System.Data.SqlClient.SqlCommand responseCommand = new System.Data.SqlClient.SqlCommand();
                    responseCommand.Connection = sc;
                    responseCommand.CommandText = "select Responses.*, CONCAT(SysUser.FirstName,' ',SysUser.LastName) as 'Name' from Responses, SysUser Where Responses.ForumID = '" + forumArray[j].getForumID() + "' And SysUser.UserID = Responses.UserID";
                    responseCommand.ExecuteNonQuery();
                    Responses[] responseArray = new Responses[countResponse];
                    SqlDataReader responseInfoReader = responseCommand.ExecuteReader();
                    if (responseInfoReader.HasRows)
                    {
                        while (responseInfoReader.Read())
                        {
                            responseArray[k] = new Responses(responseInfoReader.GetInt32(0), responseInfoReader.GetInt32(3), responseInfoReader.GetInt32(4), responseInfoReader.GetString(1), responseInfoReader.GetDateTime(2));
                            Literal response = new Literal();
                            response.Text = "<div class='response'><strong><h5>Response by: " + responseInfoReader.GetString(5) + "</h5></strong><p>" + responseInfoReader.GetString(1) + "</p></div>";
                            Button btnDelete = new Button();
                            btnDelete.ID = "btnDeleteResponse" + responseInfoReader.GetInt32(0);
                            btnDelete.Text = "Delete";
                            btnDelete.CssClass = "btn btn-danger";
                            btnDelete.Click += new EventHandler(this.deleteResponse_Click);
                            discussionPlaceHolder.Controls.Add(response);
                            discussionPlaceHolder.Controls.Add(btnDelete);
                            k++;
                        }
                    }
                    responseInfoReader.Close();
                    Literal responseSectionBefore = new Literal();
                    responseSectionBefore.Text = "<div class='reply'>";
                    TextBox txtResponse = new TextBox();
                    txtResponse.ID = "txtResponse" + forumArray[j].getForumID();
                    txtResponse.TextMode = TextBoxMode.MultiLine;
                    txtResponse.CssClass = "form-control";
                    Button btnResponse = new Button();
                    btnResponse.ID = "btnResponse" + forumArray[j].getForumID();
                    btnResponse.CssClass = "btn btn-primary btnReply";
                    btnResponse.Text = "Submit";
                    btnResponse.Click += new EventHandler(this.btnResponse_Click);
                    Literal responseAfter = new Literal();
                    responseAfter.Text = "</div></div></div></div>";

                    discussionPlaceHolder.Controls.Add(responseSectionBefore);
                    discussionPlaceHolder.Controls.Add(txtResponse);
                    discussionPlaceHolder.Controls.Add(btnResponse);
                    discussionPlaceHolder.Controls.Add(responseAfter);
                }
                catch (Exception c)
                {

                }
            }
        }
        protected void btnResponse_Click(Object sender, EventArgs e)
        {
            Button b = (Button)sender;
            string strButtonID = b.ID.ToString();
            string strTest = strButtonID.Substring(11);
            int ForumID = Convert.ToInt32(strTest);
            int countTB = 0;
            DateTime today = DateTime.Now;
            DateTime dateOnly = today.Date;
            string strToday = dateOnly.ToString("MM/dd/yyyy");
            MembershipUser User = Membership.GetUser();
            string UserEmail = User.UserName;
            foreach (Control c in discussionPlaceHolder.Controls)
            {
                if (c is TextBox)
                {
                    TextBox t = (TextBox)c;
                    if (c.ID == "txtResponse" + ForumID)
                    {
                        Responses.createResponse(new WBLWebsite.Responses(ForumID, SysUser.getUserByID(), t.Text, strToday));
                    }
                }
            }
            Response.Redirect(Request.RawUrl);
        }
        protected void deleteResponse_Click(object sender, EventArgs e)
        {
            try
            {
                Button b = (Button)sender;
                string strButtonID = b.ID.ToString();
                string strTest = strButtonID.Substring(17);
                int rID = Convert.ToInt32(strTest);
                Responses.deleteResponse(rID);
                Response.Redirect(Request.RawUrl);
            }
            catch (Exception a)
            {

            }
        }
        protected void deleteForum_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            string strButtonID = b.ID.ToString();
            string strID = strButtonID.Substring(14);
            int fID = Convert.ToInt32(strID);
            Forum.deleteForum(fID);
            Response.Redirect(Request.RawUrl);
        }
        protected void btnCreateForums_Click(object sender, EventArgs e)
        {         
            if(txtSummary.Text.Contains("-")== true)
            {
                lblValidationMessage.Text = "No SQL injections please.";
                lblValidationMessage.CssClass = "alert-danger";
                lblValidationMessage.Visible = true;
            }
            else
            {
                DateTime now = DateTime.Now;
                Forum.createForum(new Forum(getForumID(), txtTitle.Text, txtSummary.Text, now, SysUser.getUserByID()));
                txtTitle.Text = "";
                txtSummary.Text = "";
            }
        }
        public int getForumID()
        {
            int ID = 0;
            string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            string sqlQuery = "";
            SqlConnection sc = new SqlConnection(constr);
            sc.Open();
            SqlCommand command = new SqlCommand();
            command.Connection = sc;
            sqlQuery = "select ForumID from Forums order by ForumID";
            command.CommandText = sqlQuery;
            command.ExecuteNonQuery();

            SqlDataReader reader = command.ExecuteReader();

            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    ID = reader.GetInt32(0);
                }
            }
            ID++;
            sc.Close();
            return ID;
        }
    }
}

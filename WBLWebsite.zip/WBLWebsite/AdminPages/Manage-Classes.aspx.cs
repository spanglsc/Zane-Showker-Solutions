﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;


namespace WBLWebsite.AdminPages
{
    public partial class Manage_Classes : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                                             
            }
            visGrid();
            populateInstructor();
        }

        //000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
        //Creates a class
        public void createClass(object sender, EventArgs e)
        {

            string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            SqlConnection sc = new SqlConnection(constr);
            sc.Open();
            System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand();
            command.Connection = sc;

            int newClassID = Class.checkClassID();
            String newClassLocation = txtLoc.Text;
            String newClassTime = txtTime.Text;
            String newClassEndDate = txtED.Text;
            Debug.WriteLine(txtED.Text);
            String newClassStartDate = txtSD.Text;
            String newClassName = txtName.Text;
            String newClassDescription = txtDesc.Text;
            String newClassInstructor = ddInstructor.SelectedValue;

            Class newclass = new Class(newClassID, newClassName, newClassDescription, newClassTime, newClassLocation, newClassStartDate, newClassEndDate, newClassInstructor);

            int CID = newclass.getClassID();
            Debug.WriteLine(newclass.getClassID());
            String CN = newclass.getClassName();
            Debug.WriteLine(newclass.getClassName());
            String CD = newclass.getClassDescription();
            Debug.WriteLine(newclass.getClassDescription());
            String CT = newclass.getClassTime();
            Debug.WriteLine(newclass.getClassTime());
            String CL = newclass.getClassLocation();
            Debug.WriteLine(newclass.getClassLocation());
            String CSD = newclass.getStartDate();
            Debug.WriteLine(newclass.getStartDate());
            String CED = newclass.getEndDate();
            Debug.WriteLine(newclass.getEndDate());
            String CI = newclass.getClassInstructor();
            Debug.WriteLine(newclass.getClassInstructor());

            Debug.WriteLine("Classes Made");

            command.CommandText = "Select UserID from SysUser WHERE LastName = @CI";
            command.Parameters.AddWithValue("@CI", CI);

            int result = ((int)command.ExecuteScalar());
            Debug.WriteLine(result);

            command.CommandText = "insert into [WBL].[dbo].[Class] (ClassID, Title, ClassDescription, ClassTime, ClassLocation, StartDate, EndDate, UserID) values ('" + @CID + "', '" + @CN + "', '" + @CD + "', '" + @CT + "', '" + @CL + "', '" + @CSD + "', '" + @CED + "', '" + @result + "')";
            Debug.WriteLine("Classes Made");

            SqlParameter param = new SqlParameter();

            command.Parameters.AddWithValue("@CID", newclass.getClassID());
            command.Parameters.AddWithValue("@CN", newclass.getClassName());
            command.Parameters.AddWithValue("@CD", newclass.getClassDescription());
            command.Parameters.AddWithValue("@CT", newclass.getClassTime());
            command.Parameters.AddWithValue("@CL", newclass.getClassLocation());
            command.Parameters.AddWithValue("@CSD", newclass.getStartDate());
            command.Parameters.AddWithValue("@CED", newclass.getEndDate());
            command.Parameters.AddWithValue("@result", result);

            command.ExecuteNonQuery();

            sc.Close();

            Debug.WriteLine("Classes Made");

            txtName.Text = "";
            txtDesc.Text = "";
            txtTime.Text = "";
            txtLoc.Text = "";
            txtSD.Text = "";
            txtED.Text = "";
            ddInstructor.SelectedIndex = 0;
        }

        //000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
        //Deletes a class from the database
        public void deleteClass(object sender, EventArgs e)
        {
            string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            SqlConnection sc = new SqlConnection(constr);
            sc.Open();
            System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand();
            command.Connection = sc;

            int id = int.Parse((sender as LinkButton).CommandArgument);            

            command.CommandText = "DELETE FROM CLASS WHERE ClassID = @classToDelete";
            command.Parameters.AddWithValue("@classToDelete", id);

            command.ExecuteNonQuery();

            sc.Close();
        }

        //0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
        //Populates a dropdown with Instructor names from the Database for user to select
        public void populateInstructor()
        {
            string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            SqlConnection sc = new SqlConnection(constr);
            sc.Open();
            System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand();
            command.Connection = sc;

            command.CommandText = "Select * From SysUser WHERE UserType = 'Instructor'";
            DataTable dt = new DataTable();

            dt.Load(command.ExecuteReader());

            ddInstructor.DataSource = dt;
            ddInstructor.DataTextField = "LastName";
            ddInstructor.DataValueField = "LastName";

            ddInstructor.DataBind();

            sc.Close();

        }

        //000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
        //Updates the database with new class information
        public void updateClass(object sender, GridViewUpdateEventArgs e)
        {            
            string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            SqlConnection sc = new SqlConnection(constr);
            sc.Open();
            System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand();
            command.Connection = sc;

            int ClassId = Convert.ToInt32(table.DataKeys[e.RowIndex].Value.ToString());
            GridViewRow row = table.Rows[e.RowIndex];
            Label lblID = (Label)row.FindControl("lblClassID");
            TextBox textTitle = (TextBox)row.Cells[3].Controls[0];
            TextBox textDesc = (TextBox)row.Cells[4].Controls[0];
            TextBox textTime = (TextBox)row.Cells[5].Controls[0];
            TextBox textLoc = (TextBox)row.Cells[6].Controls[0];
            TextBox textSD = (TextBox)row.Cells[7].Controls[0];
            TextBox textED = (TextBox)row.Cells[8].Controls[0];
            textDesc.Rows = 5;
            textDesc.Columns = 50;
            textDesc.MaxLength = 500;
            textTitle.Width = 70;
            textTime.Width = 50;
            textTitle.Wrap = true;
            textDesc.Wrap = true;
            textTime.Wrap = true;
            textLoc.Wrap = true;
            textSD.Wrap = true;
            textED.Wrap = true;

            command.CommandText = "Select * From SysUser WHERE UserType = 'Instructor'";
            DataTable dt = new DataTable();

            dt.Load(command.ExecuteReader());

            sc.Close();

            table.EditIndex = -1;
            sc.Open();
            command.CommandText = "UPDATE Class SET Title = @Title, ClassDescription = @ClassDescription, ClassTime = @ClassTime, ClassLocation = @ClassLocation, StartDate = @StartDate, EndDate = @EndDate WHERE ClassID = '" + row.Cells[2].Text + "'";
            command.Connection = sc;
            database.UpdateCommand = command.CommandText;
            command.Parameters.AddWithValue("@Title", textTitle.Text);
            command.Parameters.AddWithValue("@ClassDescription", textDesc.Text);
            command.Parameters.AddWithValue("@ClassTime", textTime.Text);
            command.Parameters.AddWithValue("@ClassLocation", textLoc.Text);
            command.Parameters.AddWithValue("@StartDate", textSD.Text);
            command.Parameters.AddWithValue("@EndDate", textED.Text);

            command.ExecuteNonQuery();
            sc.Close();
            gvbind();

           /* String updateInstructor = ddInstructor.Text;

            command.CommandText = "Select UserID from SysUser WHERE LastName = @updateInstructor";
            command.Parameters.AddWithValue("@updateInstructor", updateInstructor);

            int result2 = ((int)command.ExecuteScalar());

            command.CommandText = "UPDATE Class SET Title = @Title, ClassDescription = @ClassDescription, ClassTime = @ClassTime, ClassLocation = @ClassLocation, StartDate = @StartDate, EndDate = @EndDate, UserID = @result2 WHERE ClassID = @intUpdateID";

            SqlParameter param = new SqlParameter();            

            command.ExecuteNonQuery();
            sc.Close();*/
        }


        //000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
        public void visGrid(object sender, EventArgs e)
        {
            table.Visible = true;
        }
        public void visGrid()
        {
            table.Visible = true;
        }
        //0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
        public void CustomersGridView_SelectedIndexChanged(Object sender, EventArgs e)
        {

            GridViewRow row = table.SelectedRow;

            String Selected = row.Cells[1].Text;
            int intSelectedClass = Convert.ToInt32(Selected);

            string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            SqlConnection sc = new SqlConnection(constr);
            sc.Open();
            System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand();
            command.Connection = sc;

            command.CommandText = "insert into ClassRoster values (@intSelectedClass, "; //get user ID and insert into the Roster Table
                                                                                         //in the view for students, select * from classes where Class ID = ClassID from the roster table and where USERID = userID gotten

            int result2 = ((int)command.ExecuteScalar());
        }
        protected void gvbind()
        {
            string instructor = ddInstructor.SelectedValue;
            
            string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            SqlConnection sc = new SqlConnection(constr);
            sc.Open();
            SqlCommand cmd = new SqlCommand("SELECT c.ClassID as ClassID, c.Title as Title, c.ClassDescription as ClassDescription, c.ClassTime as ClassTime, c.ClassLocation as ClassLocation, c.StartDate as StartDate, c.EndDate as EndDate, c.duration as Duration, c.UserID as UserID, u.LastName as LastName FROM Class c, SysUser u Where c.UserID = u.UserID ORDER BY[ClassID]", sc);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            
            if (ds.Tables[0].Rows.Count > 0)
            {
                table.DataSourceID = "database";
                sc.Close();
                table.DataBind();
            }
            else
            {
                ds.Tables[0].Rows.Add(ds.Tables[0].NewRow());
                table.DataSourceID = "database";
                table.DataBind();
                int columncount = table.Rows[0].Cells.Count;
                table.Rows[0].Cells.Clear();
                table.Rows[0].Cells.Add(new TableCell());
                table.Rows[0].Cells[0].ColumnSpan = 9;
                table.Rows[0].Cells[0].Text = "No Records Found";
            }

        }
        protected void table_RowEditing(object sender, GridViewEditEventArgs e)
        {
            table.EditIndex = e.NewEditIndex;
            gvbind();
        }
        protected void table_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            table.EditIndex = -1;
            gvbind();
        }
    }
}
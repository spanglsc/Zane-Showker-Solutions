﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;


namespace WBLWebsite.AdminPages
{
    public partial class Manage_Classes : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

            }
            populateInstructor();
        }

        //000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
        //Creates a class
        public void createClass(object sender, EventArgs e)
        {

            string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            SqlConnection sc = new SqlConnection(constr);
            sc.Open();
            System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand();
            command.Connection = sc;
            
            String newClassID = txtID.Text;
            String newClassLocation = txtLoc.Text;
            String newClassTime = txtTime.Text;
            String newClassEndDate = txtED.Text;
            Debug.WriteLine(txtED.Text);
            String newClassStartDate = txtSD.Text;
            String newClassName = txtName.Text;
            String newClassDescription = txtDesc.Text;
            String newClassInstructor = ddInstructor.Text;

            Class newclass = new Class(newClassID, newClassName, newClassDescription, newClassTime, newClassLocation, newClassStartDate, newClassEndDate, newClassInstructor);

            String CID = newclass.getClassID();
            Debug.WriteLine(newclass.getClassID());
            String CN = newclass.getClassName();
            Debug.WriteLine(newclass.getClassName());
            String CD = newclass.getClassDescription();
            Debug.WriteLine(newclass.getClassDescription());
            String CT = newclass.getClassTime();
            Debug.WriteLine(newclass.getClassTime());
            String CL = newclass.getClassLocation();
            Debug.WriteLine(newclass.getClassLocation());
            String CSD = newclass.getStartDate();
            Debug.WriteLine(newclass.getStartDate());
            String CED = newclass.getEndDate();
            Debug.WriteLine(newclass.getEndDate());
            String CI = newclass.getClassInstructor();
            Debug.WriteLine(newclass.getClassInstructor());

            Debug.WriteLine("Classes Made");

            command.CommandText = "Select UserID from SysUser WHERE LastName = @CI";
            command.Parameters.AddWithValue("@CI", CI);

            int result = ((int)command.ExecuteScalar());
            Debug.WriteLine(result);

            command.CommandText = "insert into [WBL].[dbo].[Class] (ClassID, Title, ClassDescription, ClassTime, ClassLocation, StartDate, EndDate, UserID) values ('" + @CID + "', '" + @CN + "', '" + @CD + "', '" + @CT + "', '" + @CL + "', '" + @CSD + "', '" + @CED + "', '" + @result + "')";
            Debug.WriteLine("Classes Made");

            SqlParameter param = new SqlParameter();


            command.Parameters.AddWithValue("@CID", newclass.getClassID());
            command.Parameters.AddWithValue("@CN", newclass.getClassName());
            command.Parameters.AddWithValue("@CD", newclass.getClassDescription());
            command.Parameters.AddWithValue("@CT", newclass.getClassTime());
            command.Parameters.AddWithValue("@CL", newclass.getClassLocation());
            command.Parameters.AddWithValue("@CSD", newclass.getStartDate());
            command.Parameters.AddWithValue("@CED", newclass.getEndDate());
            command.Parameters.AddWithValue("@result", result);

            command.ExecuteNonQuery();


            sc.Close();

            Debug.WriteLine("Classes Made");


        }

        //000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
        //Deletes a class from the database
        public void deleteClass(object sender, EventArgs e)
        {
            string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            SqlConnection sc = new SqlConnection(constr);
            sc.Open();
            System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand();
            command.Connection = sc;

            //command.CommandText = "insert into [WBL].[dbo].[Class] (ClassID, Title, ClassDescription, ClassTime, ClassLocation, StartDate, EndDate, UserID) values ('" + @CID + "', '" + @CN + "', '" + @CD + "', '" + @CT + "', '" + @CL + "', '" + @CSD + "', '" + @CED + "', '" + @CI + "')";
            //Debug.WriteLine("Classes Made");

            //String classID = txtDelete.Text;
            //int classToDelete = Convert.ToInt32(classID);

            //command.CommandText = "DELETE FROM CLASS WHERE ClassID = @classToDelete";
            //command.Parameters.AddWithValue("@classToDelete", classToDelete);

            command.ExecuteNonQuery();

            sc.Close();
        }

        //0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
        //Populates a dropdown with Instructor names from the Database for user to select
        public void populateInstructor()
        {

            string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            SqlConnection sc = new SqlConnection(constr);
            sc.Open();
            System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand();
            command.Connection = sc;

            command.CommandText = "Select * From SysUser WHERE UserType = 'Instructor'";
            DataTable dt = new DataTable();

            dt.Load(command.ExecuteReader());

            ddInstructor.DataSource = dt;
            ddInstructor.DataTextField = "LastName";
            ddInstructor.DataValueField = "LastName";

            ddInstructor.DataBind();

            sc.Close();

        }

        //000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
        //Updates the database with new class information
        public void updateClass(object sender, EventArgs e)
        {

            string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            SqlConnection sc = new SqlConnection(constr);
            sc.Open();
            System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand();
            command.Connection = sc;

            //String updateID = txtUpdate.Text;
            //int intUpdateID = Convert.ToInt32(updateID);

            String updateInstructor = ddInstructor.Text;

            command.CommandText = "Select UserID from SysUser WHERE LastName = @updateInstructor";
            command.Parameters.AddWithValue("@updateInstructor", updateInstructor);

            int result2 = ((int)command.ExecuteScalar());

            command.CommandText = "UPDATE Class SET ClassID = @ClassID, Title = @Title, ClassDescription = @ClassDescription, ClassTime = @ClassTime, ClassLocation = @ClassLocation, StartDate = @StartDate, EndDate = @EndDate, UserID = @result2 WHERE ClassID = @intUpdateID";

            SqlParameter param = new SqlParameter();

            command.Parameters.AddWithValue("@ClassID", txtID.Text);
            command.Parameters.AddWithValue("@Title", txtName.Text);
            command.Parameters.AddWithValue("@ClassDescription", txtDesc.Text);
            command.Parameters.AddWithValue("@ClassTime", txtTime.Text);
            command.Parameters.AddWithValue("@ClassLocation", txtLoc.Text);
            command.Parameters.AddWithValue("@StartDate", txtSD.Text);
            command.Parameters.AddWithValue("@EndDate", txtED.Text);
            command.Parameters.AddWithValue("@result2", result2);
            //command.Parameters.AddWithValue("@intUpdateID", intUpdateID);

            command.ExecuteNonQuery();
            sc.Close();
        }


        //000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
        public void visGrid(object sender, EventArgs e)
        {
            table.Visible = true;
            table.DataSourceID = "database";

        }
        //0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
        public void CustomersGridView_SelectedIndexChanged(Object sender, EventArgs e)
        {

            GridViewRow row = table.SelectedRow;

            String Selected = row.Cells[1].Text;
            int intSelectedClass = Convert.ToInt32(Selected);

            string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            SqlConnection sc = new SqlConnection(constr);
            sc.Open();
            System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand();
            command.Connection = sc;

            command.CommandText = "insert into ClassRoster values (@intSelectedClass, "; //get user ID and insert into the Roster Table
                                                                                         //in the view for students, select * from classes where Class ID = ClassID from the roster table and where USERID = userID gotten

            int result2 = ((int)command.ExecuteScalar());


        }


    }
}
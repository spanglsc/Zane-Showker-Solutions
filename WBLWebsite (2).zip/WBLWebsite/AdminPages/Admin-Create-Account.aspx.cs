﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WBLWebsite.AdminPages
{
    public partial class Admin_Create_Account : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            MembershipUser User = Membership.GetUser();
            txtAdminCreateEmail.Text = User.UserName;
        }
        protected void btnAdminCreateAccount_Click(object sender, EventArgs e)
        {
            Membership.CreateUser(txtAdminCreateEmail.Text, txtAdminCreatePass.Text);
            SysUser.createUser(new SysUser(txtAdminCreateLName.Text, txtAdminCreateFName.Text, "10/29/1993", "dfasdf", "dsfawdfa", "dsfawdfa", 19380, "dfsdfdsf", txtAdminCreateEmail.Text, "dsfawdfa", selAdminUserType.Value.ToString(), "fgsdfg"));
            Roles.AddUserToRole(txtAdminCreateEmail.Text, selAdminUserType.Value.ToString());
        }
        protected void btnLogout_Click(object sender, EventArgs e)
        {
            FormsAuthentication.SignOut();
            Session.Abandon();

            // clear authentication cookie
            HttpCookie cookie1 = new HttpCookie(FormsAuthentication.FormsCookieName, "");
            cookie1.Expires = DateTime.Now.AddYears(-1);
            Response.Cookies.Add(cookie1);
            FormsAuthentication.RedirectToLoginPage();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WBLWebsite
{
    public partial class UserLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void UserLoginControls_Authenticate(object sender, AuthenticateEventArgs e)
        {
            if (Membership.ValidateUser(UserLoginControls.UserName, UserLoginControls.Password) == true)
            {

                e.Authenticated = true;
                string[] role = Roles.GetRolesForUser(UserLoginControls.UserName);
                if (role[0] != "Administrator" && e.Authenticated == true)
                {
                    FormsAuthentication.RedirectFromLoginPage(UserLoginControls.UserName, true);
                }
                else if (role[0] == "Administrator")
                {
                    Session["user"] = User.Identity.Name;
                    FormsAuthentication.RedirectFromLoginPage(UserLoginControls.UserName, true);
                    bool test = Roles.IsUserInRole(User.Identity.Name, "Administrators");
                }
            }
            else
            {
                Response.Write("Invalid Login");
            }
        }
    }
}
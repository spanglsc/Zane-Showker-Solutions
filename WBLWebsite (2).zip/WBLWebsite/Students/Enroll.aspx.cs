﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Security;

namespace WBLWebsite.Students
{
    public partial class Enroll : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        public void visGrid(object sender, EventArgs e)
        {
            table.Visible = true;
            table.DataSourceID = "database";
        }
        public void CustomersGridView_SelectedIndexChanged(Object sender, EventArgs e)
        {

            GridViewRow row = table.SelectedRow;

            String Selected = row.Cells[1].Text;
            int intSelectedClass = Convert.ToInt32(Selected);

            string constr = ConfigurationManager.ConnectionStrings["WBLConnectionString"].ConnectionString;
            SqlConnection sc = new SqlConnection(constr);
            sc.Open();
            System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand();
            command.Connection = sc;
            MembershipUser User = Membership.GetUser();
            string UserEmail = User.UserName;
            command.CommandText = "select UserID from sysuser where email = '" + UserEmail + "'";
            command.ExecuteNonQuery();
            SqlDataReader reader = command.ExecuteReader();
            int result = 0;
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    result = reader.GetInt32(0);
                }
            }
            reader.Close();
            command.CommandText = "insert into StudentClass values (@intSelectedClass, @result)"; //get user ID and insert into the Roster Table
                                                                                                  //in the view for students, select * from classes where Class ID = ClassID from the roster table and where USERID = userID gotten

            command.Parameters.AddWithValue("@intSelectedClass", intSelectedClass);
            command.Parameters.AddWithValue("@result", result);

            command.ExecuteNonQuery();
            sc.Close();
        }
    }
}
